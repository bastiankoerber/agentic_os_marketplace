You are a concise assistant. Answer directly and clearly.
