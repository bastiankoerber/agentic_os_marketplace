const BASE_URL = "https://api.github.com";

exports.invoke = async (toolId, input, context) => {
  switch (toolId) {
    case "github.searchRepos":
      return searchRepos(input, context);
    case "github.getFile":
      return getFile(input, context);
    case "github.listIssues":
      return listIssues(input, context);
    case "github.listLabels":
      return listLabels(input, context);
    case "github.listIssueEvents":
      return listIssueEvents(input, context);
    default:
      throw new Error(`Unknown tool: ${toolId}`);
  }
};

async function searchRepos(input, context) {
  const query = String(input?.query || "").trim();
  if (!query) throw new Error("github.searchRepos requires 'query'");

  const perPage = clampNumber(input?.per_page, 1, 100, resolveMaxItems(context, 5));
  const token = resolveToken(input, context);
  const timeoutMs = resolveTimeout(input, context);
  const endpoint = `${BASE_URL}/search/repositories?q=${encodeURIComponent(query)}&per_page=${perPage}`;

  const data = await requestJson(endpoint, { token, timeoutMs });
  const items = Array.isArray(data.items)
    ? data.items.map((repo) => ({
        full_name: repo.full_name,
        html_url: repo.html_url,
        description: repo.description || "",
        stargazers_count: repo.stargazers_count || 0,
        language: repo.language || null,
        updated_at: repo.updated_at
      }))
    : [];

  return {
    total_count: Number(data.total_count || 0),
    items,
    mode: token ? "authenticated" : "unauthenticated"
  };
}

async function getFile(input, context) {
  const owner = resolveOwner(input, context);
  const repo = resolveRepo(input, context);
  const filePath = String(input?.path || "").trim();
  if (!owner || !repo || !filePath) {
    throw new Error("github.getFile requires 'owner', 'repo', and 'path'");
  }

  const ref = String(input?.ref || "").trim();
  const token = resolveToken(input, context);
  const timeoutMs = resolveTimeout(input, context);

  const url = new URL(`${BASE_URL}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${encodeURIComponent(filePath).replace(/%2F/g, "/")}`);
  if (ref) url.searchParams.set("ref", ref);

  const data = await requestJson(url.toString(), { token, timeoutMs });
  const encoded = typeof data.content === "string" ? data.content.replace(/\n/g, "") : "";
  const decoded = encoded ? Buffer.from(encoded, "base64").toString("utf-8") : "";

  return {
    path: data.path || filePath,
    sha: data.sha || "",
    size: Number(data.size || 0),
    content: decoded,
    mode: token ? "authenticated" : "unauthenticated"
  };
}

async function listIssues(input, context) {
  const owner = resolveOwner(input, context);
  const repo = resolveRepo(input, context);
  if (!owner || !repo) throw new Error("github.listIssues requires 'owner' and 'repo'");

  const state = String(input?.state || "open");
  const perPage = clampNumber(input?.per_page, 1, 100, resolveMaxItems(context, 30));
  const maxPages = clampNumber(input?.max_pages, 1, 10, resolveMaxPages(context, 1));
  const labels = normalizeLabels(input?.labels);
  const token = resolveToken(input, context);
  const timeoutMs = resolveTimeout(input, context);

  const query = new URLSearchParams();
  query.set("state", state);
  if (labels.length) query.set("labels", labels.join(","));
  const data = await fetchPaginated(`/repos/${enc(owner)}/${enc(repo)}/issues?${query.toString()}`, {
    perPage,
    maxPages,
    token,
    timeoutMs
  });

  const items = data
    .filter((issue) => !issue.pull_request)
    .map((issue) => ({
      id: issue.id,
      number: issue.number,
      title: issue.title,
      state: issue.state,
      html_url: issue.html_url,
      user: issue.user?.login || "",
      assignee: issue.assignee?.login || null,
      created_at: issue.created_at,
      updated_at: issue.updated_at,
      closed_at: issue.closed_at,
      labels: Array.isArray(issue.labels) ? issue.labels.map((label) => (typeof label === "string" ? label : label.name)) : []
    }));

  return {
    items,
    issues: items,
    mode: token ? "authenticated" : "unauthenticated"
  };
}

async function listLabels(input, context) {
  const owner = resolveOwner(input, context);
  const repo = resolveRepo(input, context);
  if (!owner || !repo) throw new Error("github.listLabels requires 'owner' and 'repo'");

  const perPage = clampNumber(input?.per_page, 1, 100, resolveMaxItems(context, 100));
  const maxPages = clampNumber(input?.max_pages, 1, 10, resolveMaxPages(context, 5));
  const token = resolveToken(input, context);
  const timeoutMs = resolveTimeout(input, context);

  const labels = await fetchPaginated(`/repos/${enc(owner)}/${enc(repo)}/labels`, {
    perPage,
    maxPages,
    token,
    timeoutMs
  });

  return {
    labels: labels.map((label) => ({
      id: label.id,
      name: label.name,
      color: label.color,
      description: label.description || ""
    })),
    mode: token ? "authenticated" : "unauthenticated"
  };
}

async function listIssueEvents(input, context) {
  const owner = resolveOwner(input, context);
  const repo = resolveRepo(input, context);
  const issueNumber = Number(input?.issue_number);
  if (!owner || !repo || !Number.isInteger(issueNumber) || issueNumber <= 0) {
    throw new Error("github.listIssueEvents requires 'owner', 'repo', and positive integer 'issue_number'");
  }

  const perPage = clampNumber(input?.per_page, 1, 100, resolveMaxItems(context, 100));
  const maxPages = clampNumber(input?.max_pages, 1, 10, resolveMaxPages(context, 3));
  const token = resolveToken(input, context);
  const timeoutMs = resolveTimeout(input, context);

  const events = await fetchPaginated(`/repos/${enc(owner)}/${enc(repo)}/issues/${issueNumber}/events`, {
    perPage,
    maxPages,
    token,
    timeoutMs
  });

  return {
    events: events.map((event) => ({
      id: event.id,
      event: event.event,
      created_at: event.created_at,
      label: event.label?.name || null
    })),
    mode: token ? "authenticated" : "unauthenticated"
  };
}

async function fetchPaginated(endpoint, options) {
  const results = [];
  for (let page = 1; page <= options.maxPages; page += 1) {
    const url = new URL(endpoint.startsWith("http") ? endpoint : `${BASE_URL}${endpoint}`);
    if (!url.searchParams.has("per_page")) url.searchParams.set("per_page", String(options.perPage));
    url.searchParams.set("page", String(page));
    const data = await requestJson(url.toString(), { token: options.token, timeoutMs: options.timeoutMs });
    if (!Array.isArray(data) || !data.length) break;
    results.push(...data);
    if (data.length < options.perPage) break;
  }
  return results;
}

function resolveToken(input, context) {
  const inputToken = String(input?.token || "").trim();
  if (inputToken) return inputToken;

  const settings = (context && context.settings) || {};
  if (typeof settings.token === "string" && settings.token.trim()) {
    return settings.token.trim();
  }
  if (typeof settings.github_token === "string" && settings.github_token.trim()) {
    return settings.github_token.trim();
  }
  return "";
}

function resolveOwner(input, context) {
  const owner = String(input?.owner || "").trim();
  if (owner) return owner;
  const settings = (context && context.settings) || {};
  if (typeof settings.owner === "string" && settings.owner.trim()) return settings.owner.trim();
  if (typeof settings.default_owner === "string" && settings.default_owner.trim()) return settings.default_owner.trim();
  return "";
}

function resolveRepo(input, context) {
  const repo = String(input?.repo || "").trim();
  if (repo) return repo;
  const settings = (context && context.settings) || {};
  if (typeof settings.repo === "string" && settings.repo.trim()) return settings.repo.trim();
  if (typeof settings.default_repo === "string" && settings.default_repo.trim()) return settings.default_repo.trim();
  return "";
}

function resolveMaxItems(context, fallback) {
  const settings = (context && context.settings) || {};
  return clampNumber(settings.max_items, 1, 100, fallback);
}

function resolveMaxPages(context, fallback) {
  const settings = (context && context.settings) || {};
  return clampNumber(settings.max_pages, 1, 10, fallback);
}

function normalizeLabels(value) {
  if (Array.isArray(value)) return value.map((v) => String(v || "").trim()).filter(Boolean);
  if (typeof value === "string") return value.split(",").map((v) => v.trim()).filter(Boolean);
  return [];
}

function resolveTimeout(input, context) {
  const settings = (context && context.settings) || {};
  const fromInput = Number(input?.timeout_ms);
  const fromSettings = Number(settings.timeout_ms);
  if (!Number.isNaN(fromInput)) return clampNumber(fromInput, 2000, 60000, 15000);
  if (!Number.isNaN(fromSettings)) return clampNumber(fromSettings, 2000, 60000, 15000);
  return 15000;
}

async function requestJson(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs);
  try {
    const headers = {
      Accept: "application/vnd.github+json",
      "User-Agent": "agenticos-chat-studio"
    };
    if (options.token) {
      headers.Authorization = `Bearer ${options.token}`;
    }

    const response = await fetch(url, {
      method: "GET",
      headers,
      signal: controller.signal
    });

    const text = await response.text();
    const data = safeJson(text);
    if (!response.ok) {
      const detail = data?.message || text || `status ${response.status}`;
      throw new Error(`GitHub API error: ${detail}`);
    }

    return data;
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new Error(`GitHub request timed out after ${options.timeoutMs}ms`);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

function safeJson(input) {
  try {
    return JSON.parse(input || "null");
  } catch {
    return null;
  }
}

function clampNumber(value, min, max, fallback) {
  const num = Number(value);
  if (Number.isNaN(num)) return fallback;
  return Math.max(min, Math.min(max, num));
}

function enc(value) {
  return encodeURIComponent(String(value));
}
