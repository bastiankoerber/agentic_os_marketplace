Chat Studio sample app for Agentic OS.

Features:
- Codex-style chat workspace and rich composer
- Source chips in the composer (`+ Add Source`)
- Provider + model selection
- GitHub tool toggle directly in the composer
- GitHub tool settings managed in Shell -> Settings -> Tools Catalog (token optional, unauthenticated fallback)
- Chat settings saved in backend SQLite per app
- Controls: system prompt, temperature, top_p, max tokens, presence penalty, frequency penalty, stream
- Session event stream output
