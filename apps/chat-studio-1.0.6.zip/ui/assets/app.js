const appId = window.AgenticOS.appId || "com.example.chat-studio";
const SETTINGS_KEY = "chat.studio";
const GLOBAL_SETTINGS_KEY = "apps.chat.defaults";
const PROVIDER_PREF_KEY = "chat.studio.selectedProvider";
const THEME_SETTINGS_KEY = "apps.theme";

const el = {
  sessionName: document.getElementById("session-name"),
  provider: document.getElementById("provider"),
  newSession: document.getElementById("new-session"),
  chatLog: document.getElementById("chat-log"),
  chatForm: document.getElementById("chat-form"),
  message: document.getElementById("message"),
  send: document.getElementById("send"),
  composerSettingsBtn: document.getElementById("composer-settings-btn"),
  composerSettingsPopover: document.getElementById("composer-settings-popover"),
  runModel: document.getElementById("run-model"),
  runAutoTools: document.getElementById("run-auto-tools"),
  runMaxSteps: document.getElementById("run-max-steps"),
  runUseMemory: document.getElementById("run-use-memory"),
  runMemoryTurns: document.getElementById("run-memory-turns"),
  runIncludeToolMessages: document.getElementById("run-include-tool-messages"),
  runIncludeSystemMessages: document.getElementById("run-include-system-messages"),
  runToolsStatus: document.getElementById("run-tools-status"),
  toolChipList: document.getElementById("tool-chip-list"),
  status: document.getElementById("status"),
  systemPrompt: document.getElementById("system-prompt"),
  temperature: document.getElementById("temperature"),
  topP: document.getElementById("top-p"),
  maxTokens: document.getElementById("max-tokens"),
  presencePenalty: document.getElementById("presence-penalty"),
  frequencyPenalty: document.getElementById("frequency-penalty"),
  stream: document.getElementById("stream"),
  enableGithubSetting: document.getElementById("settings-enable-github"),
  resetAppSettings: document.getElementById("reset-app-settings"),
  saveSettings: document.getElementById("save-settings")
};

const defaults = {
  system_prompt: "",
  temperature: 0.2,
  top_p: 1,
  max_tokens: 700,
  presence_penalty: 0,
  frequency_penalty: 0,
  stream: true,
  run: {
    auto_tools: true,
    max_steps: 4,
    use_memory: true,
    memory_turns: 8,
    include_tool_messages: false,
    include_system_messages: false
  },
  tools: {
    github: true
  }
};

const state = {
  providers: [],
  defaultProviderId: "",
  selectedProvider: "",
  selectedModel: "",
  sessionId: "",
  settings: { ...defaults },
  globalSettings: { ...defaults },
  appSettings: { ...defaults },
  pendingAssistantNode: null,
  unsubscribe: null,
  isSending: false,
  waitingTimer: null,
  firstTokenAt: 0,
  pluginSettingsHintShown: false,
  popoverOpen: false,
  githubStatus: "Checking GitHub status...",
  providerSource: ""
};

const GITHUB_TOOL_IDS = ["github.searchRepos", "github.getFile", "github.listIssues"];

init();

async function init() {
  el.sessionName.textContent = "Session";
  await loadTheme();
  bindActions();
  subscribeThemeChanges();
  await loadSettingsFromBackend();
  renderSettingsForm();
  await loadProviders();
  await refreshToolStatus();
  renderToolAccess();
  await createSession(true);
}

async function loadTheme() {
  try {
    const res = await window.AgenticOS.rpc.invoke("settings.get", { key: THEME_SETTINGS_KEY });
    const theme = res.value === "dark" ? "dark" : "light";
    applyTheme(theme);
  } catch (_err) {
    applyTheme("light");
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme === "dark" ? "dark" : "light");
}

function subscribeThemeChanges() {
  window.AgenticOS.rpc.onEvent((event) => {
    if (event?.type !== "settings.changed") return;
    const data = event?.data && typeof event.data === "object" ? event.data : {};
    if (data.key !== THEME_SETTINGS_KEY) return;
    applyTheme(data.value);
  });
  window.addEventListener("focus", () => {
    loadTheme().catch(() => {});
  });
}

function bindActions() {
  el.newSession.addEventListener("click", () => createSession(true));

  el.provider.addEventListener("change", async () => {
    state.selectedProvider = el.provider.value;
    state.providerSource = "app preference";
    try {
      await window.AgenticOS.rpc.invoke("appSettings.set", { appId, key: PROVIDER_PREF_KEY, value: state.selectedProvider });
    } catch {
      // ignore
    }
    hydrateModels();
    renderToolAccess();
  });

  el.runModel.addEventListener("change", () => {
    state.selectedModel = el.runModel.value;
  });

  el.runAutoTools.addEventListener("change", () => {
    state.settings.run.auto_tools = !!el.runAutoTools.checked;
  });

  el.runMaxSteps.addEventListener("change", () => {
    state.settings.run.max_steps = clampNumber(el.runMaxSteps.value, 1, 8, 4);
    el.runMaxSteps.value = String(state.settings.run.max_steps);
  });

  el.runUseMemory.addEventListener("change", () => {
    state.settings.run.use_memory = !!el.runUseMemory.checked;
  });

  el.runMemoryTurns.addEventListener("change", () => {
    state.settings.run.memory_turns = clampNumber(el.runMemoryTurns.value, 1, 30, 8);
    el.runMemoryTurns.value = String(state.settings.run.memory_turns);
  });

  el.runIncludeToolMessages.addEventListener("change", () => {
    state.settings.run.include_tool_messages = !!el.runIncludeToolMessages.checked;
  });

  el.runIncludeSystemMessages.addEventListener("change", () => {
    state.settings.run.include_system_messages = !!el.runIncludeSystemMessages.checked;
  });

  el.composerSettingsBtn.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleComposerPopover();
  });

  document.addEventListener("click", (event) => {
    if (!state.popoverOpen) return;
    const target = event.target;
    if (!(target instanceof Node)) return;
    if (el.composerSettingsPopover.contains(target) || el.composerSettingsBtn.contains(target)) return;
    closeComposerPopover();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && state.popoverOpen) {
      closeComposerPopover();
      el.composerSettingsBtn.focus();
    }
  });

  el.chatForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    await submitMessage();
  });

  el.message.addEventListener("keydown", async (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      await submitMessage();
    }
  });

  el.saveSettings.addEventListener("click", saveAppSettingsToBackend);
  el.resetAppSettings.addEventListener("click", resetAppSettingsOverride);
}

async function loadSettingsFromBackend() {
  try {
    const [globalResult, appResult] = await Promise.all([
      window.AgenticOS.rpc.invoke("settings.get", { key: GLOBAL_SETTINGS_KEY }),
      window.AgenticOS.rpc.invoke("appSettings.get", {
        appId,
        key: SETTINGS_KEY
      })
    ]);

    const globalValue = globalResult.value && typeof globalResult.value === "object" ? globalResult.value : {};
    const appValue = appResult.value && typeof appResult.value === "object" ? appResult.value : {};

    if (!state.pluginSettingsHintShown && appValue.github && typeof appValue.github === "object") {
      state.pluginSettingsHintShown = true;
      setStatus("Legacy GitHub settings detected. Configure GitHub in Shell -> Settings.");
    }

    state.globalSettings = mergeSettings(globalValue);
    state.appSettings = toPartialSettings(appValue);
    recomputeEffectiveSettings();
  } catch (err) {
    setStatus(`Settings load failed: ${err.message || String(err)}`, true);
  }
}

function mergeSettings(input, base = defaults) {
  return {
    ...base,
    ...input,
    run: {
      ...base.run,
      ...(input.run || {})
    },
    tools: {
      ...base.tools,
      ...(input.tools || {})
    }
  };
}

function toPartialSettings(input) {
  const source = input && typeof input === "object" ? input : {};
  return {
    ...source,
    run: source.run && typeof source.run === "object" ? { ...source.run } : {},
    tools: source.tools && typeof source.tools === "object" ? { ...source.tools } : {}
  };
}

function recomputeEffectiveSettings() {
  state.settings = mergeSettings(state.appSettings, state.globalSettings);
}

function renderSettingsForm() {
  el.systemPrompt.value = String(state.settings.system_prompt || "");
  el.temperature.value = String(state.settings.temperature);
  el.topP.value = String(state.settings.top_p);
  el.maxTokens.value = String(state.settings.max_tokens);
  el.presencePenalty.value = String(state.settings.presence_penalty);
  el.frequencyPenalty.value = String(state.settings.frequency_penalty);
  el.stream.checked = !!state.settings.stream;

  el.enableGithubSetting.checked = !!state.settings.tools.github;
  el.runAutoTools.checked = !!state.settings.run.auto_tools;
  el.runMaxSteps.value = String(clampNumber(state.settings.run.max_steps, 1, 8, 4));
  el.runUseMemory.checked = !!state.settings.run.use_memory;
  el.runMemoryTurns.value = String(clampNumber(state.settings.run.memory_turns, 1, 30, 8));
  el.runIncludeToolMessages.checked = !!state.settings.run.include_tool_messages;
  el.runIncludeSystemMessages.checked = !!state.settings.run.include_system_messages;

  renderToolAccess();
}

function collectSettingsFromForm() {
  return {
    system_prompt: String(el.systemPrompt.value || ""),
    temperature: Number(el.temperature.value || 0.2),
    top_p: Number(el.topP.value || 1),
    max_tokens: Number(el.maxTokens.value || 700),
    presence_penalty: Number(el.presencePenalty.value || 0),
    frequency_penalty: Number(el.frequencyPenalty.value || 0),
    stream: !!el.stream.checked,
    run: {
      auto_tools: !!el.runAutoTools.checked,
      max_steps: clampNumber(el.runMaxSteps.value, 1, 8, 4),
      use_memory: !!el.runUseMemory.checked,
      memory_turns: clampNumber(el.runMemoryTurns.value, 1, 30, 8),
      include_tool_messages: !!el.runIncludeToolMessages.checked,
      include_system_messages: !!el.runIncludeSystemMessages.checked
    },
    tools: {
      github: !!el.enableGithubSetting.checked
    }
  };
}

async function saveAppSettingsToBackend() {
  const payload = mergeSettings(collectSettingsFromForm());
  try {
    await window.AgenticOS.rpc.invoke("appSettings.set", {
      appId,
      key: SETTINGS_KEY,
      value: payload
    });
    state.appSettings = payload;
    recomputeEffectiveSettings();
    renderSettingsForm();
    await refreshToolStatus();
    renderToolAccess();
    setStatus("App override saved");
  } catch (err) {
    setStatus(`Settings save failed: ${err.message || String(err)}`, true);
  }
}

async function resetAppSettingsOverride() {
  try {
    await window.AgenticOS.rpc.invoke("appSettings.set", {
      appId,
      key: SETTINGS_KEY,
      value: {}
    });
    state.appSettings = {};
    recomputeEffectiveSettings();
    renderSettingsForm();
    await refreshToolStatus();
    renderToolAccess();
    setStatus("App override reset to global defaults");
  } catch (err) {
    setStatus(`Reset failed: ${err.message || String(err)}`, true);
  }
}

function renderToolAccess() {
  const enabled = !!state.settings.tools.github;
  const memoryEnabled = !!state.settings.run.use_memory;
  const memoryTurns = clampNumber(state.settings.run.memory_turns, 1, 30, 8);
  el.toolChipList.innerHTML = "";
  const chip = document.createElement("div");
  chip.className = `tool-chip ${enabled ? "ready" : "off"}`;
  chip.textContent = enabled ? `GitHub (${state.githubStatus})` : "GitHub disabled";
  el.toolChipList.appendChild(chip);

  const memoryChip = document.createElement("div");
  memoryChip.className = `tool-chip ${memoryEnabled ? "ready" : "off"}`;
  memoryChip.textContent = memoryEnabled ? `Memory (${memoryTurns} turns)` : "Memory off";
  el.toolChipList.appendChild(memoryChip);

  el.runToolsStatus.innerHTML = "";
  const row = document.createElement("div");
  row.className = "tool-status-row";
  row.textContent = enabled
    ? `GitHub tool is enabled. ${state.githubStatus}. Configure token in Admin -> Tools.`
    : "GitHub tool is disabled in app settings.";
  el.runToolsStatus.appendChild(row);

  const memoryRow = document.createElement("div");
  memoryRow.className = "tool-status-row";
  memoryRow.textContent = memoryEnabled
    ? `Session memory enabled for last ${memoryTurns} user turns${state.settings.run.include_tool_messages ? ", including tool messages" : ""}${state.settings.run.include_system_messages ? ", including system messages" : ""}.`
    : "Session memory is disabled; each run uses only the current user input.";
  el.runToolsStatus.appendChild(memoryRow);

  const providerRow = document.createElement("div");
  providerRow.className = "tool-status-row";
  providerRow.textContent = `Provider source: ${state.providerSource || "unknown"}`;
  el.runToolsStatus.appendChild(providerRow);
}

async function loadProviders() {
  await loadDefaultProvider();
  const result = await window.AgenticOS.rpc.invoke("providers.list", {});
  state.providers = result.providers || [];

  if (!state.providers.some((provider) => provider.id === "local")) {
    state.providers.push({
      id: "local",
      name: "Local",
      models: ["local-default"],
      available: true
    });
  }

  el.provider.innerHTML = "";
  for (const provider of state.providers) {
    const option = document.createElement("option");
    option.value = provider.id;
    option.textContent = provider.available ? provider.name : `${provider.name} (offline)`;
    el.provider.appendChild(option);
  }

  let fromPrefs = "";
  try {
    const pref = await window.AgenticOS.rpc.invoke("appSettings.get", { appId, key: PROVIDER_PREF_KEY });
    fromPrefs = normalizeProviderId(String(pref?.value || ""));
  } catch {
    fromPrefs = "";
  }
  const fromAdmin = normalizeProviderId(state.defaultProviderId);
  const firstAvailable = state.providers.find((p) => p.available) || state.providers[0];
  state.selectedProvider = [fromPrefs, fromAdmin, firstAvailable?.id || ""]
    .find((id) => id && state.providers.some((provider) => provider.id === id)) || "";
  if (state.selectedProvider && state.selectedProvider === fromPrefs) state.providerSource = "app preference";
  else if (state.selectedProvider && state.selectedProvider === fromAdmin) state.providerSource = "admin default";
  else state.providerSource = "first available";
  el.provider.value = state.selectedProvider;
  hydrateModels();
}

async function loadDefaultProvider() {
  try {
    const res = await window.AgenticOS.rpc.invoke("settings.get", { key: "providers.default" });
    state.defaultProviderId = normalizeProviderId(String(res?.value || ""));
  } catch {
    state.defaultProviderId = "";
  }
}

function normalizeProviderId(value) {
  const id = String(value || "").trim();
  if (id === "github") return "github-copilot";
  return id;
}

function hydrateModels() {
  const provider = state.providers.find((p) => p.id === state.selectedProvider);
  const models = provider?.models || [];
  el.runModel.innerHTML = "";
  for (const model of models) {
    const option = document.createElement("option");
    option.value = model;
    option.textContent = model;
    el.runModel.appendChild(option);
  }
  const previous = state.selectedModel;
  state.selectedModel = models.includes(previous) ? previous : models[0] || "";
  el.runModel.value = state.selectedModel;
}

async function createSession(clearChat) {
  const result = await window.AgenticOS.agent.startSession(appId, state.selectedProvider || undefined);
  state.sessionId = result.sessionId || result.id;
  el.sessionName.textContent = `Session ${state.sessionId.slice(0, 8)}`;
  bindEventStream();
  if (clearChat) {
    el.chatLog.innerHTML = "";
  }
}

function bindEventStream() {
  if (!state.sessionId) return;
  if (state.unsubscribe) {
    state.unsubscribe();
    state.unsubscribe = null;
  }

  window.AgenticOS.rpc.invoke("sessions.subscribeEvents", { sessionId: state.sessionId });

  state.unsubscribe = window.AgenticOS.rpc.onEvent((event) => {
    if (event.sessionId !== state.sessionId) return;

    if (event.type === "llm.delta") {
      const delta = event.data?.delta || "";
      if (!state.pendingAssistantNode) {
        state.pendingAssistantNode = appendMessage("assistant", "", true);
      }
      if (!state.firstTokenAt) {
        state.firstTokenAt = Date.now();
        stopWaitingStatus();
        setStatus("Streaming...");
      }
      if (state.pendingAssistantNode.dataset.thinking === "1") {
        state.pendingAssistantNode.textContent = "";
        state.pendingAssistantNode.classList.remove("thinking");
        state.pendingAssistantNode.dataset.thinking = "0";
      }
      state.pendingAssistantNode.textContent = mergeDeltaText(state.pendingAssistantNode.textContent || "", String(delta));
      scrollLog();
      return;
    }

    if (event.type === "tool.error") {
      appendMessage("system", `Tool error: ${event.data?.message || "unknown"}`);
      return;
    }

    if (event.type === "agent.step") {
      const index = Number(event.data?.index || 0);
      appendMessage("system", `Agent step ${index}...`);
      return;
    }

    if (event.type === "agent.tool.call") {
      const toolId = event.data?.toolId || "unknown";
      appendMessage("tool", `Calling tool: ${toolId}`);
      return;
    }

    if (event.type === "agent.tool.result") {
      const toolId = event.data?.toolId || "unknown";
      appendMessage("tool", `Tool result (${toolId}):\n${JSON.stringify(event.data?.output || {}, null, 2)}`);
      return;
    }

    if (event.type === "agent.final") {
      setStatus("Agent completed");
      return;
    }

    if (event.type === "agent.error") {
      appendMessage("system", `Agent error: ${event.data?.message || "unknown"}`);
      setStatus("Agent error", true);
    }
  });
}

async function submitMessage() {
  if (state.isSending) return;
  const content = String(el.message.value || "").trim();
  if (!content) return;

  if (!state.sessionId) {
    await createSession(false);
  }

  state.isSending = true;
  closeComposerPopover();
  el.send.disabled = true;
  state.firstTokenAt = 0;
  appendMessage("user", content);
  el.message.value = "";
  state.pendingAssistantNode = appendMessage("assistant", "Thinking...", true);
  startWaitingStatus();

  try {
    const contextMessages = await buildContextMessages();
    const enabledToolIds = [];
    if (state.settings.tools.github && state.settings.run.auto_tools) {
      enabledToolIds.push(...GITHUB_TOOL_IDS);
    }

    const response = await window.AgenticOS.rpc.invoke("sessions.runAgent", {
      sessionId: state.sessionId,
      providerId: state.selectedProvider || undefined,
      model: state.selectedModel || undefined,
      userMessage: content,
      systemPrompt: state.settings.system_prompt || undefined,
      contextMessages,
      enabledToolIds,
      maxSteps: clampNumber(state.settings.run.max_steps, 1, 8, 4),
      temperature: Number(state.settings.temperature),
      top_p: Number(state.settings.top_p),
      max_tokens: Number(state.settings.max_tokens),
      presence_penalty: Number(state.settings.presence_penalty),
      frequency_penalty: Number(state.settings.frequency_penalty),
      stream: !!state.settings.stream
    });

    const text = response?.content || "";
    if (state.pendingAssistantNode) {
      if (state.pendingAssistantNode.dataset.thinking === "1") {
        state.pendingAssistantNode.textContent = text;
      } else if (!state.pendingAssistantNode.textContent && text) {
        state.pendingAssistantNode.textContent = text;
      }
      state.pendingAssistantNode.classList.remove("thinking");
      state.pendingAssistantNode.dataset.thinking = "0";
      state.pendingAssistantNode = null;
    } else {
      appendMessage("assistant", text);
    }
    stopWaitingStatus();
    setStatus("Ready");
  } catch (err) {
    stopWaitingStatus();
    const text = `Error: ${err.message || String(err)}`;
    if (state.pendingAssistantNode) {
      state.pendingAssistantNode.textContent = text;
      state.pendingAssistantNode.classList.remove("thinking");
      state.pendingAssistantNode.dataset.thinking = "0";
      state.pendingAssistantNode = null;
    } else {
      appendMessage("system", text);
    }
    setStatus("Error", true);
  } finally {
    state.isSending = false;
    el.send.disabled = false;
  }
}

async function buildContextMessages() {
  if (!state.sessionId) return [];
  if (!state.settings.run.use_memory) return [];

  const includeTools = !!state.settings.run.include_tool_messages;
  const includeSystem = !!state.settings.run.include_system_messages;
  const maxTurns = clampNumber(state.settings.run.memory_turns, 1, 30, 8);

  const res = await window.AgenticOS.rpc.invoke("sessions.messages", {
    sessionId: state.sessionId
  });
  const all = Array.isArray(res?.messages) ? res.messages : [];

  const allowed = all.filter((msg) => {
    const role = String(msg?.role || "");
    if (role === "user" || role === "assistant") return true;
    if (role === "tool") return includeTools;
    if (role === "system") return includeSystem;
    return false;
  });

  const collected = [];
  let seenUserTurns = 0;
  for (let idx = allowed.length - 1; idx >= 0; idx -= 1) {
    const msg = allowed[idx];
    const role = String(msg?.role || "");
    const content = String(msg?.content || "");
    if (!content.trim()) continue;
    collected.push({ role, content });
    if (role === "user") {
      seenUserTurns += 1;
      if (seenUserTurns >= maxTurns) break;
    }
  }

  return collected.reverse();
}

async function refreshToolStatus() {
  if (!state.settings.tools.github) {
    state.githubStatus = "disabled";
    return;
  }

  try {
    const config = await window.AgenticOS.rpc.invoke("plugins.getSettings", { pluginId: "tool.github", appId });
    const settings = config.settings && typeof config.settings === "object" ? config.settings : {};
    state.githubStatus = typeof settings.token === "string" && settings.token.trim() ? "token configured" : "unauthenticated";
  } catch (_err) {
    state.githubStatus = "not configured";
  }
}

function toggleComposerPopover() {
  if (state.popoverOpen) {
    closeComposerPopover();
  } else {
    openComposerPopover();
  }
}

function openComposerPopover() {
  state.popoverOpen = true;
  el.composerSettingsPopover.classList.remove("hidden");
  el.composerSettingsBtn.setAttribute("aria-expanded", "true");
}

function closeComposerPopover() {
  state.popoverOpen = false;
  el.composerSettingsPopover.classList.add("hidden");
  el.composerSettingsBtn.setAttribute("aria-expanded", "false");
}

function appendMessage(kind, text, thinking = false) {
  const node = document.createElement("div");
  node.className = `msg ${kind}`;
  if (thinking) {
    node.classList.add("thinking");
    node.dataset.thinking = "1";
  } else {
    node.dataset.thinking = "0";
  }
  node.textContent = text;
  el.chatLog.appendChild(node);
  scrollLog();
  return node;
}

function scrollLog() {
  el.chatLog.scrollTop = el.chatLog.scrollHeight;
}

function mergeDeltaText(existing, delta) {
  if (!delta) return existing;
  if (!existing) return delta;
  if (delta.startsWith(existing)) return delta;
  if (existing.endsWith(delta)) return existing;

  const maxOverlap = Math.min(existing.length, delta.length);
  for (let overlap = maxOverlap; overlap > 0; overlap -= 1) {
    if (existing.endsWith(delta.slice(0, overlap))) {
      return existing + delta.slice(overlap);
    }
  }

  return existing + delta;
}

function setStatus(text, isError = false) {
  el.status.textContent = text;
  el.status.classList.toggle("error", isError);
}

function startWaitingStatus() {
  stopWaitingStatus();
  const startedAt = Date.now();
  setStatus("Waiting for first token...");
  state.waitingTimer = setInterval(() => {
    if (state.firstTokenAt) return;
    const sec = Math.floor((Date.now() - startedAt) / 1000);
    setStatus(`Waiting for first token... ${sec}s (model may be loading)`);
  }, 1000);
}

function stopWaitingStatus() {
  if (state.waitingTimer) {
    clearInterval(state.waitingTimer);
    state.waitingTimer = null;
  }
}

function clampNumber(value, min, max, fallback) {
  const num = Number(value);
  if (Number.isNaN(num)) return fallback;
  return Math.max(min, Math.min(max, num));
}
