const APP_ID = window.AgenticOS.appId || "com.example.strategy-reality-check";
const THEME_SETTINGS_KEY = "apps.theme";
const MODE_KEY = "strategyRealityCheck.mode";
const RELEASE_KEY = "strategyRealityCheck.release";
const PROVIDER_PREF_KEY = "strategyRealityCheck.selectedProvider";
const PRODUCT_REPO_KEY = "strategyRealityCheck.productRepo";
const STRATEGY_REPO_KEY = "strategyRealityCheck.strategyRepo";
const STRATEGY_REF_KEY = "strategyRealityCheck.strategyRef";
const STRATEGY_PATH_KEY = "strategyRealityCheck.strategyPath";
const STRATEGY_INCLUDE_KEY = "strategyRealityCheck.includeFiles";
const STATUS_PROJECT_ORG = "camunda";
const STATUS_PROJECT_NUMBER = 9;
const WEIGHT_TARGET = 0.7;
const WEIGHT_POTENTIAL = 0.3;
const BATCH_SIZE = 10;
const COMPRESS_EVERY = 4;
const MAX_SNIPPETS_PER_BATCH = 8;
const MAX_SNIPPET_CHARS = 900;
const PASTE_BATCH_SIZE = 6;
const MAX_PASTE_BASELINE_SNIPPETS = 14;
const RATE_LIMIT_WAIT_MS = 65000;

const el = {
  subhead: document.getElementById("subhead"),
  sessionName: document.getElementById("session-name"),
  authBanner: document.getElementById("auth-banner"),
  filesBtn: document.getElementById("files-btn"),
  reviewMode: document.getElementById("review-mode"),
  releaseControl: document.getElementById("release-control"),
  releaseCycle: document.getElementById("release-cycle"),
  provider: document.getElementById("provider"),
  runModel: document.getElementById("run-model"),
  providerHint: document.getElementById("provider-hint"),
  fileCount: document.getElementById("file-count"),
  buildPanel: document.getElementById("build-panel"),
  buildStage: document.getElementById("build-stage"),
  buildDetail: document.getElementById("build-detail"),
  buildProgressBar: document.getElementById("build-progress-bar"),
  toggleThinking: document.getElementById("toggle-thinking"),
  thinkingLog: document.getElementById("thinking-log"),
  askForm: document.getElementById("ask-form"),
  question: document.getElementById("question"),
  pasteReviewPanel: document.getElementById("paste-review-panel"),
  pasteInput: document.getElementById("paste-input"),
  pasteHighlighted: document.getElementById("paste-highlighted"),
  pasteFindings: document.getElementById("paste-findings"),
  status: document.getElementById("status"),
  ask: document.getElementById("ask"),
  dashboard: document.getElementById("dashboard"),
  filesModal: document.getElementById("files-modal"),
  filesClose: document.getElementById("files-close"),
  productRepoInput: document.getElementById("product-repo-input"),
  strategyRepoInput: document.getElementById("strategy-repo-input"),
  strategyRefInput: document.getElementById("strategy-ref-input"),
  strategyPathInput: document.getElementById("strategy-path-input"),
  repoRefresh: document.getElementById("repo-refresh"),
  filesSearch: document.getElementById("files-search"),
  filesList: document.getElementById("files-list"),
  filesSave: document.getElementById("files-save"),
  filesSelectAll: document.getElementById("files-select-all"),
  filesClear: document.getElementById("files-clear")
};

const state = {
  sessionId: "",
  providers: [],
  defaultProviderId: "",
  selectedProvider: "",
  providerSource: "",
  mode: "release",
  selectedModel: "",
  owner: "camunda",
  repo: "product-hub",
  selectedRelease: "",
  tokenConfigured: false,
  availableReleases: [],
  strategyOwner: "camunda",
  strategyRepo: "product-strategy",
  strategyRef: "main",
  strategyPath: "",
  availableStrategyFiles: [],
  includeFiles: [],
  pasteFindings: [],
  pasteParagraphs: [],
  running: false,
  build: {
    active: false,
    showThinking: false,
    steps: [],
    batches: 0,
    compressionRounds: 0,
    retries: 0,
    partialFailures: 0
  }
};

init();

async function init() {
  await loadTheme();
  bindActions();
  subscribeThemeChanges();
  await loadProviders();
  await ensureSession(true);
  await loadToolConfig();
  await loadSettings();
  updateModeUI();
  await refreshReleaseOptions();
  await refreshStrategyFiles();
  renderFileModal();
  renderWelcome();
}

function bindActions() {
  el.askForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    await runAnalysis();
  });
  el.reviewMode.addEventListener("change", async () => {
    const next = String(el.reviewMode.value || "release").trim();
    state.mode = next === "paste" ? "paste" : "release";
    await persist(MODE_KEY, state.mode);
    updateModeUI();
  });
  el.releaseCycle.addEventListener("change", async () => {
    state.selectedRelease = String(el.releaseCycle.value || "").trim();
    await persist(RELEASE_KEY, state.selectedRelease);
  });
  el.provider.addEventListener("change", async () => {
    state.selectedProvider = el.provider.value;
    state.providerSource = "app preference";
    try {
      await window.AgenticOS.rpc.invoke("appSettings.set", { appId: APP_ID, key: PROVIDER_PREF_KEY, value: state.selectedProvider });
    } catch {
      // ignore
    }
    hydrateModels();
    renderProviderHint();
    await ensureSession(true);
  });
  el.runModel.addEventListener("change", () => {
    state.selectedModel = el.runModel.value;
  });
  el.toggleThinking.addEventListener("click", () => {
    state.build.showThinking = !state.build.showThinking;
    renderThinkingPanel();
  });
  el.filesBtn.addEventListener("click", () => {
    hydrateRepoInputs();
    el.filesModal.classList.remove("hidden");
  });
  el.filesClose.addEventListener("click", () => {
    el.filesModal.classList.add("hidden");
  });
  el.filesSearch.addEventListener("input", renderFileModal);
  el.filesSelectAll.addEventListener("click", () => {
    state.includeFiles = [...state.availableStrategyFiles];
    renderFileModal();
  });
  el.filesClear.addEventListener("click", () => {
    state.includeFiles = [];
    renderFileModal();
  });
  el.filesSave.addEventListener("click", async () => {
    applyRepoInputs();
    await persistRepoSettings();
    await persist(STRATEGY_INCLUDE_KEY, state.includeFiles);
    renderFileCount();
    el.filesModal.classList.add("hidden");
  });
  el.repoRefresh.addEventListener("click", async () => {
    applyRepoInputs();
    await persistRepoSettings();
    await refreshReleaseOptions();
    await refreshStrategyFiles();
    renderFileModal();
  });
}

async function loadTheme() {
  try {
    const res = await window.AgenticOS.rpc.invoke("settings.get", { key: THEME_SETTINGS_KEY });
    applyTheme(res?.value);
  } catch {
    applyTheme("light");
  }
}

function applyTheme(value) {
  document.documentElement.setAttribute("data-theme", value === "dark" ? "dark" : "light");
}

function subscribeThemeChanges() {
  window.AgenticOS.rpc.onEvent((event) => {
    if (event?.type !== "settings.changed") return;
    const data = event?.data && typeof event.data === "object" ? event.data : {};
    if (data.key !== THEME_SETTINGS_KEY) return;
    applyTheme(data.value);
  });
  window.addEventListener("focus", () => {
    loadTheme().catch(() => {});
  });
}

async function loadProviders() {
  await loadDefaultProvider();
  const result = await window.AgenticOS.rpc.invoke("providers.list", {});
  state.providers = result.providers || [];
  if (!state.providers.some((item) => item.id === "local")) {
    state.providers.push({ id: "local", name: "Local", models: ["local-default"], available: true });
  }
  el.provider.innerHTML = "";
  state.providers.forEach((provider) => {
    const option = document.createElement("option");
    option.value = provider.id;
    option.textContent = provider.available ? provider.name : `${provider.name} (offline)`;
    el.provider.appendChild(option);
  });
  let fromPrefs = "";
  try {
    const pref = await window.AgenticOS.rpc.invoke("appSettings.get", { appId: APP_ID, key: PROVIDER_PREF_KEY });
    fromPrefs = normalizeProviderId(String(pref?.value || ""));
  } catch {
    fromPrefs = "";
  }
  const fromAdmin = normalizeProviderId(state.defaultProviderId);
  const firstAvailable = state.providers.find((item) => item.available) || state.providers[0] || null;
  state.selectedProvider = [fromPrefs, fromAdmin, firstAvailable?.id || ""]
    .find((id) => id && state.providers.some((provider) => provider.id === id)) || "local";
  if (state.selectedProvider && state.selectedProvider === fromPrefs) state.providerSource = "app preference";
  else if (state.selectedProvider && state.selectedProvider === fromAdmin) state.providerSource = "admin default";
  else state.providerSource = "first available";
  el.provider.value = state.selectedProvider;
  hydrateModels();
  renderProviderHint();
}

async function loadDefaultProvider() {
  try {
    const res = await window.AgenticOS.rpc.invoke("settings.get", { key: "providers.default" });
    state.defaultProviderId = normalizeProviderId(String(res?.value || ""));
  } catch {
    state.defaultProviderId = "";
  }
}

function normalizeProviderId(value) {
  const id = String(value || "").trim();
  if (id === "github") return "github-copilot";
  return id;
}

function hydrateModels() {
  const provider = state.providers.find((item) => item.id === state.selectedProvider);
  const models = provider?.models || ["local-default"];
  el.runModel.innerHTML = "";
  models.forEach((model) => {
    const option = document.createElement("option");
    option.value = model;
    option.textContent = model;
    el.runModel.appendChild(option);
  });
  state.selectedModel = models[0] || "";
  el.runModel.value = state.selectedModel;
}

async function ensureSession(force = false) {
  if (state.sessionId && !force) return;
  const result = await window.AgenticOS.agent.startSession(APP_ID, state.selectedProvider || undefined);
  state.sessionId = result.sessionId || result.id;
  el.sessionName.textContent = `Session ${String(state.sessionId).slice(0, 8)}`;
}

async function loadToolConfig() {
  try {
    const primary = await window.AgenticOS.rpc.invoke("plugins.getSettings", { pluginId: "tool.github", appId: APP_ID });
    const settings = primary.settings && typeof primary.settings === "object" ? primary.settings : {};
    state.owner = String(settings.owner || settings.default_owner || "camunda").trim() || "camunda";
    state.repo = String(settings.repo || settings.default_repo || "product-hub").trim() || "product-hub";
    state.tokenConfigured = typeof settings.token === "string" && settings.token.trim().length > 0;
    el.subhead.textContent = `${state.owner}/${state.repo} vs ${state.strategyOwner}/${state.strategyRepo}`;
  } catch {
    state.tokenConfigured = false;
  }
  el.authBanner.classList.toggle("hidden", state.tokenConfigured);
  if (!state.tokenConfigured) {
    el.authBanner.textContent = "GitHub PAT required. Configure token in Admin -> Tools -> GitHub.";
  }
}

async function loadSettings() {
  const savedMode = await loadSetting(MODE_KEY, "release");
  state.mode = String(savedMode || "release").trim() === "paste" ? "paste" : "release";
  el.reviewMode.value = state.mode;
  state.selectedRelease = await loadSetting(RELEASE_KEY, "");
  const savedProductRepo = await loadSetting(PRODUCT_REPO_KEY, `${state.owner}/${state.repo}`);
  const productParts = String(savedProductRepo || "").split("/").map((v) => v.trim()).filter(Boolean);
  if (productParts.length >= 2) {
    state.owner = productParts[0];
    state.repo = productParts[1];
  }
  state.strategyRepo = await loadSetting(STRATEGY_REPO_KEY, state.strategyRepo);
  state.strategyRef = await loadSetting(STRATEGY_REF_KEY, "main");
  state.strategyPath = await loadSetting(STRATEGY_PATH_KEY, "");
  const include = await loadSetting(STRATEGY_INCLUDE_KEY, []);
  state.includeFiles = Array.isArray(include) ? include.map((v) => String(v || "")).filter(Boolean) : [];

  const parts = String(state.strategyRepo || "").split("/").map((v) => v.trim()).filter(Boolean);
  if (parts.length >= 2) {
    state.strategyOwner = parts[0];
    state.strategyRepo = parts[1];
  }
  el.subhead.textContent = `${state.owner}/${state.repo} vs ${state.strategyOwner}/${state.strategyRepo}`;
  hydrateRepoInputs();
}

function updateModeUI() {
  const pasteMode = state.mode === "paste";
  if (el.reviewMode) {
    el.reviewMode.value = pasteMode ? "paste" : "release";
  }
  if (el.releaseControl) {
    el.releaseControl.classList.toggle("hidden", pasteMode);
  }
  if (el.pasteReviewPanel) {
    el.pasteReviewPanel.classList.toggle("hidden", !pasteMode);
  }
  if (el.question) {
    el.question.placeholder = pasteMode
      ? "Optional review lens (for example: focus on GTM clarity and product positioning)..."
      : "Ask for strategy reality check and messaging...";
  }
  if (el.ask) {
    el.ask.textContent = pasteMode ? "Review Paste" : "Analyze";
  }
}

function hydrateRepoInputs() {
  if (el.productRepoInput) el.productRepoInput.value = `${state.owner}/${state.repo}`;
  if (el.strategyRepoInput) el.strategyRepoInput.value = `${state.strategyOwner}/${state.strategyRepo}`;
  if (el.strategyRefInput) el.strategyRefInput.value = state.strategyRef || "main";
  if (el.strategyPathInput) el.strategyPathInput.value = state.strategyPath || "";
}

function applyRepoInputs() {
  const productRepo = String(el.productRepoInput?.value || "").trim();
  const strategyRepo = String(el.strategyRepoInput?.value || "").trim();
  const strategyRef = String(el.strategyRefInput?.value || "").trim();
  const strategyPath = String(el.strategyPathInput?.value || "").trim();

  const productParts = productRepo.split("/").map((v) => v.trim()).filter(Boolean);
  if (productParts.length >= 2) {
    state.owner = productParts[0];
    state.repo = productParts[1];
  }

  const strategyParts = strategyRepo.split("/").map((v) => v.trim()).filter(Boolean);
  if (strategyParts.length >= 2) {
    state.strategyOwner = strategyParts[0];
    state.strategyRepo = strategyParts[1];
  }

  state.strategyRef = strategyRef || "main";
  state.strategyPath = strategyPath;
  el.subhead.textContent = `${state.owner}/${state.repo} vs ${state.strategyOwner}/${state.strategyRepo}`;
}

async function persistRepoSettings() {
  await Promise.all([
    persist(PRODUCT_REPO_KEY, `${state.owner}/${state.repo}`),
    persist(STRATEGY_REPO_KEY, `${state.strategyOwner}/${state.strategyRepo}`),
    persist(STRATEGY_REF_KEY, state.strategyRef),
    persist(STRATEGY_PATH_KEY, state.strategyPath)
  ]);
}

async function loadSetting(key, fallback) {
  try {
    const res = await window.AgenticOS.rpc.invoke("appSettings.get", { appId: APP_ID, key });
    return res?.value ?? fallback;
  } catch {
    return fallback;
  }
}

async function persist(key, value) {
  try {
    await window.AgenticOS.rpc.invoke("appSettings.set", { appId: APP_ID, key, value });
  } catch {
    // non-blocking
  }
}

async function refreshReleaseOptions() {
  el.releaseCycle.innerHTML = "";
  if (!state.tokenConfigured) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "No token";
    el.releaseCycle.appendChild(option);
    el.releaseCycle.disabled = true;
    return;
  }
  const catalog = await getReleaseLabelCatalog();
  state.availableReleases = [...(catalog.releases || [])].sort((a, b) => compareSemver(b, a));
  if (!state.availableReleases.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "No release labels found";
    el.releaseCycle.appendChild(option);
    el.releaseCycle.disabled = true;
    state.selectedRelease = "";
    setStatus("No release labels detected in Product Hub repo", true);
    return;
  }

  el.releaseCycle.disabled = false;
  if (!state.selectedRelease) {
    state.selectedRelease = state.availableReleases[0] || "";
  }
  for (const release of state.availableReleases) {
    const option = document.createElement("option");
    option.value = release;
    option.textContent = release;
    el.releaseCycle.appendChild(option);
  }
  if (state.selectedRelease) {
    el.releaseCycle.value = state.selectedRelease;
    await persist(RELEASE_KEY, state.selectedRelease);
  }
}

async function refreshStrategyFiles() {
  if (!state.tokenConfigured) return;
  const pathPrefix = String(state.strategyPath || "").trim();
  const result = await invokeInsight("github.listRepoFiles", {
    owner: state.strategyOwner,
    repo: state.strategyRepo,
    ref: state.strategyRef || "main",
    path: pathPrefix,
    include_glob: "**/*.md"
  });
  state.availableStrategyFiles = Array.isArray(result.files) ? result.files : [];
  if (!state.includeFiles.length) {
    state.includeFiles = [...state.availableStrategyFiles];
  } else {
    const allowed = new Set(state.availableStrategyFiles);
    state.includeFiles = state.includeFiles.filter((file) => allowed.has(file));
  }
  renderFileCount();
}

function renderFileModal() {
  const q = String(el.filesSearch.value || "").trim().toLowerCase();
  const include = new Set(state.includeFiles);
  el.filesList.innerHTML = "";
  state.availableStrategyFiles
    .filter((file) => !q || file.toLowerCase().includes(q))
    .forEach((file) => {
      const row = document.createElement("label");
      row.className = "file-row";
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = include.has(file);
      checkbox.addEventListener("change", () => {
        if (checkbox.checked) include.add(file);
        else include.delete(file);
        state.includeFiles = Array.from(include);
        renderFileCount();
      });
      const text = document.createElement("span");
      text.textContent = file;
      row.appendChild(checkbox);
      row.appendChild(text);
      el.filesList.appendChild(row);
    });
}

function renderFileCount() {
  el.fileCount.textContent = `${state.includeFiles.length} files selected`;
}

function renderProviderHint() {
  if (!el.providerHint) return;
  el.providerHint.textContent = `Provider source: ${state.providerSource || "unknown"}`;
}

async function runAnalysis() {
  if (state.running) return;
  const question = String(el.question.value || "").trim();
  if (!state.includeFiles.length) {
    setStatus("Select at least one strategy file", true);
    return;
  }
  if (!state.tokenConfigured) {
    setStatus("GitHub token is required", true);
    return;
  }

  if (state.mode === "paste") {
    await runPasteAnalysis(question);
    return;
  }
  if (!question) return;
  if (!state.selectedRelease) {
    setStatus("Select a release first", true);
    return;
  }

  await runReleaseAnalysis(question);
}

async function runReleaseAnalysis(question) {
  state.running = true;
  el.ask.disabled = true;
  startBuildFlow();
  setStatus("Loading release epics...");
  try {
    setBuildStage("Resolving release scope", 10, "Loading target and potential labels");
    const targetScope = await resolveScopeLabelsForRelease(state.selectedRelease, "target");
    const potentialScope = await resolveScopeLabelsForRelease(state.selectedRelease, "potential");
    const [targetIssuesRaw, potentialIssuesRaw] = await Promise.all([
      getIssuesForLabels(targetScope.labels),
      getIssuesForLabels(potentialScope.labels)
    ]);

    const targetEpics = targetIssuesRaw;
    const potentialEpics = potentialIssuesRaw;
    const deduped = new Map();
    for (const issue of targetEpics) deduped.set(String(issue.id || issue.number), { ...issue, scope: "target" });
    for (const issue of potentialEpics) {
      const key = String(issue.id || issue.number);
      if (!deduped.has(key)) deduped.set(key, { ...issue, scope: "potential" });
    }
    const epics = Array.from(deduped.values());

    setBuildStage("Auditing scope coverage", 28, "Checking release and epic label overlap in repository");
    const allIssuesPool = await getAllIssuesForAudit();
    const releaseLabeledIssues = allIssuesPool.filter((issue) => hasReleaseLabelFor(issue, state.selectedRelease));
    const epicLabeledIssues = allIssuesPool.filter((issue) => hasEpicLabel(issue));
    const strictSet = new Set(epics.map((issue) => String(issue.number)));
    const nonEpicInScope = epics
      .filter((issue) => !hasEpicLabel(issue))
      .map((issue) => ({ ...issue, note: "Included without kind:epic label" }));
    const epicWithoutRelease = epicLabeledIssues
      .filter((issue) => !hasReleaseLabelFor(issue, state.selectedRelease) && !strictSet.has(String(issue.number)))
      .map((issue) => ({
        ...issue,
        excludedReason: issueHasAnyReleaseLabel(issue)
          ? `Tagged for different release than ${state.selectedRelease}`
          : `No release label for ${state.selectedRelease}`
      }));

    setBuildStage("Loading strategy documents", 22, `${state.includeFiles.length} selected files`);
    setStatus("Loading strategy documents...");
    const docs = await loadSelectedStrategyDocs();
    const strategyIndex = buildStrategySnippetIndex(docs);

    setBuildStage("Resolving project statuses", 34, `${epics.length} epics in release scope`);
    setStatus("Resolving project statuses...");
    const epicsWithStatus = await Promise.all(epics.map(async (issue) => {
      const statusRes = await invokeInsight("github.getIssueProjectFields", {
        owner: state.owner,
        repo: state.repo,
        issue_number: Number(issue.number),
        org: STATUS_PROJECT_ORG,
        project_number: STATUS_PROJECT_NUMBER,
        status_field: "Status"
      }).catch(() => ({ status: "" }));
      return {
        ...issue,
        projectStatus: String(statusRes.status || "").trim() || "Unmapped"
      };
    }));

    setBuildStage("Running batched analysis", 45, `Batch size ${BATCH_SIZE}, compression every ${COMPRESS_EVERY}`);
    setStatus("Running strategy analysis...");
    const analysis = await runBatchedAnalysis(question, epicsWithStatus, strategyIndex);
    const scopeAudit = {
      releaseLabeledTotal: releaseLabeledIssues.length,
      epicLabeledTotal: epicLabeledIssues.length,
      strictOverlapTotal: epicsWithStatus.length,
      nonEpicInScopeTotal: nonEpicInScope.length,
      epicOnlyTotal: epicWithoutRelease.length,
      nonEpicInScope,
      epicOnly: epicWithoutRelease
    };
    renderDashboard(epicsWithStatus, docs, analysis, scopeAudit);
    setBuildStage("Completed", 100, `Batches ${analysis?.audit?.batches || 0}, compression rounds ${analysis?.audit?.compressionRounds || 0}`);
    setStatus("Analysis ready");
  } catch (error) {
    setStatus(String(error?.message || "Analysis failed"), true);
    setBuildStage("Analysis failed", 100, String(error?.message || "Unknown error"));
  } finally {
    state.running = false;
    el.ask.disabled = false;
    finishBuildFlow();
  }
}

async function runPasteAnalysis(question) {
  const rawPaste = String(el.pasteInput?.value || "").trim();
  if (!rawPaste) {
    setStatus("Paste a document to review", true);
    return;
  }
  const paragraphs = splitPastedParagraphs(rawPaste);
  if (!paragraphs.length) {
    setStatus("Paste includes no analyzable paragraphs", true);
    return;
  }

  state.running = true;
  el.ask.disabled = true;
  startBuildFlow();
  setStatus("Loading strategy baseline...");

  try {
    setBuildStage("Loading strategy documents", 16, `${state.includeFiles.length} selected files`);
    const docs = await loadSelectedStrategyDocs();
    const baseline = buildPasteBaselineSnippets(docs, MAX_PASTE_BASELINE_SNIPPETS);
    if (!baseline.length) {
      throw new Error("Selected strategy files are empty; choose files with content");
    }

    const findings = [];
    const batches = chunkArray(paragraphs.map((text, idx) => ({ index: idx, text })), PASTE_BATCH_SIZE);
    for (let i = 0; i < batches.length; i += 1) {
      const batchNo = i + 1;
      setBuildStage(
        "Analyzing pasted paragraphs",
        20 + Math.round((batchNo / Math.max(1, batches.length)) * 64),
        `Batch ${batchNo}/${batches.length} with ${batches[i].length} paragraphs`
      );
      const batchFindings = await runPasteBatchAnalysis(question, batches[i], baseline, batchNo, batches.length);
      findings.push(...batchFindings);
      if (batchNo < batches.length) {
        await sleep(700);
      }
    }

    state.pasteParagraphs = paragraphs;
    state.pasteFindings = normalizePasteFindings(findings, paragraphs.length);
    renderPasteReviewResults();
    setBuildStage("Completed", 100, `Reviewed ${paragraphs.length} paragraphs`);
    setStatus("Paste review ready");
  } catch (error) {
    setStatus(String(error?.message || "Paste review failed"), true);
    setBuildStage("Analysis failed", 100, String(error?.message || "Unknown error"));
  } finally {
    state.running = false;
    el.ask.disabled = false;
    finishBuildFlow();
  }
}

async function loadSelectedStrategyDocs() {
  return Promise.all(state.includeFiles.map(async (file) => {
    const contentRes = await invokeInsight("github.getFile", {
      owner: state.strategyOwner,
      repo: state.strategyRepo,
      path: file,
      ref: state.strategyRef || "main"
    });
    return {
      path: file,
      content: String(contentRes.content || "")
    };
  }));
}

async function runPasteBatchAnalysis(question, batchParagraphs, baselineSnippets, batchNo, totalBatches) {
  const lens = question || "Find misalignment with strategy intent and message clarity.";
  const response = await runAgentWithRetry({
    sessionId: state.sessionId,
    providerId: state.selectedProvider || undefined,
    model: state.selectedModel || undefined,
    systemPrompt: "You are a strict strategy reviewer. Return JSON only.",
    userMessage: [
      `Review lens: ${lens}`,
      `Batch ${batchNo}/${totalBatches}`,
      "Evaluate only the pasted paragraphs for alignment risks.",
      "Use baseline snippets only as directional context; do not report issues in baseline docs.",
      "Return JSON: { findings:[{ paragraphIndex:number, severity:'none|low|medium|high|critical', title:string, rationale:string, baselineReference:string, rewrite:string }] }",
      "Rules:",
      "- Mark severity high/critical only when meaning materially conflicts with baseline strategy.",
      "- Keep rewrite empty unless severity is high or critical.",
      `Paragraphs: ${JSON.stringify(batchParagraphs)}`,
      `BaselineSnippets: ${JSON.stringify(baselineSnippets)}`
    ].join("\n"),
    enabledToolIds: [],
    maxSteps: 3,
    stream: false
  });
  const parsed = parseJson(String(response?.content || ""));
  const findings = Array.isArray(parsed?.findings) ? parsed.findings : [];
  return findings;
}

function splitPastedParagraphs(text) {
  return String(text || "")
    .replace(/\r/g, "")
    .split(/\n\s*\n/g)
    .map((part) => part.trim())
    .filter((part) => part.length >= 25)
    .slice(0, 180);
}

function buildPasteBaselineSnippets(docs, maxSnippets) {
  const snippets = [];
  for (const doc of docs || []) {
    const parts = String(doc.content || "")
      .replace(/\r/g, "")
      .split(/\n\s*\n/g)
      .map((part) => part.trim())
      .filter(Boolean)
      .slice(0, 12);
    parts.forEach((part, idx) => {
      snippets.push({
        path: String(doc.path || ""),
        ref: `${doc.path}#${idx + 1}`,
        content: part.slice(0, 900)
      });
    });
  }
  return snippets.slice(0, maxSnippets);
}

function normalizePasteFindings(items, paragraphCount) {
  const byParagraph = new Map();
  for (const item of items || []) {
    const index = Number(item?.paragraphIndex);
    if (!Number.isFinite(index) || index < 0 || index >= paragraphCount) continue;
    const severity = normalizeSeverity(item?.severity);
    const prev = byParagraph.get(index);
    if (!prev || severityRank(severity) > severityRank(prev.severity)) {
      byParagraph.set(index, {
        paragraphIndex: index,
        severity,
        title: String(item?.title || "Paste alignment risk").trim(),
        rationale: String(item?.rationale || "").trim(),
        baselineReference: String(item?.baselineReference || item?.citationPath || "").trim(),
        rewrite: severityRank(severity) >= severityRank("high") ? String(item?.rewrite || "").trim() : ""
      });
    }
  }
  return Array.from(byParagraph.values()).sort((a, b) => severityRank(b.severity) - severityRank(a.severity) || a.paragraphIndex - b.paragraphIndex);
}

function renderPasteReviewResults() {
  const findingsByParagraph = new Map((state.pasteFindings || []).map((item) => [item.paragraphIndex, item]));
  el.pasteHighlighted.innerHTML = "";
  state.pasteParagraphs.forEach((paragraph, index) => {
    const finding = findingsByParagraph.get(index);
    const severity = finding?.severity || "none";
    const row = document.createElement("div");
    row.className = `paste-paragraph${severity !== "none" ? ` flag-${severity}` : ""}`;
    row.innerHTML = [
      `<div class='finding-meta'>Paragraph ${index + 1}${severity !== "none" ? ` - ${severity.toUpperCase()}` : ""}</div>`,
      `<div>${escapeHtml(paragraph)}</div>`
    ].join("");
    el.pasteHighlighted.appendChild(row);
  });

  el.pasteFindings.innerHTML = "";
  if (!state.pasteFindings.length) {
    el.pasteFindings.textContent = "No major misalignments found in pasted text.";
    el.pasteFindings.classList.add("muted");
    return;
  }
  el.pasteFindings.classList.remove("muted");
  state.pasteFindings.forEach((item) => {
    if (item.severity === "none") return;
    const card = document.createElement("article");
    card.className = "finding-card";
    card.innerHTML = [
      `<div class='finding-meta'>Paragraph ${item.paragraphIndex + 1} - ${escapeHtml(item.severity.toUpperCase())}</div>`,
      `<div class='finding-title'>${escapeHtml(item.title || "Alignment risk")}</div>`,
      `<div>${escapeHtml(item.rationale || "No rationale provided")}</div>`,
      item.baselineReference ? `<div class='muted'>Baseline reference: ${escapeHtml(item.baselineReference)}</div>` : "",
      item.rewrite ? `<div class='finding-rewrite'><strong>Suggested rewrite:</strong> ${escapeHtml(item.rewrite)}</div>` : ""
    ].join("");
    el.pasteFindings.appendChild(card);
  });
}

function normalizeSeverity(value) {
  const level = String(value || "").trim().toLowerCase();
  if (["critical", "high", "medium", "low", "none"].includes(level)) return level;
  return "none";
}

function severityRank(level) {
  const normalized = normalizeSeverity(level);
  if (normalized === "critical") return 4;
  if (normalized === "high") return 3;
  if (normalized === "medium") return 2;
  if (normalized === "low") return 1;
  return 0;
}

async function runBatchedAnalysis(question, epics, strategyIndex) {
  const batches = chunkArray(epics, BATCH_SIZE);
  state.build.batches = batches.length;
  state.build.compressionRounds = 0;
  state.build.retries = 0;
  state.build.partialFailures = 0;

  const batchSummaries = [];
  const itemResults = [];

  for (let i = 0; i < batches.length; i += 1) {
    const batch = batches[i];
    const batchNo = i + 1;
    const snippets = selectStrategySnippetsForBatch(batch, strategyIndex, MAX_SNIPPETS_PER_BATCH);
    setBuildStage("Analyzing epic batch", 45 + Math.round((batchNo / Math.max(1, batches.length)) * 35), `Batch ${batchNo}/${batches.length} with ${batch.length} epics`);

    const batchResult = await runBatchWithRetry(question, batch, snippets, batchNo, batches.length);
    if (!batchResult || typeof batchResult !== "object") {
      state.build.partialFailures += 1;
      appendThinking(`Batch ${batchNo} failed after retry; continuing with partial result.`);
      continue;
    }
    const items = Array.isArray(batchResult.items) ? batchResult.items : [];
    const summaryText = String(batchResult.batchSummary || "").trim();
    itemResults.push(...items);
    batchSummaries.push({
      batch: batchNo,
      itemCount: items.length,
      summary: summaryText || `Batch ${batchNo}: ${items.length} items`
    });

    if (batchSummaries.length >= COMPRESS_EVERY) {
      const compressed = await compressSummaries(batchSummaries);
      state.build.compressionRounds += 1;
      batchSummaries.length = 0;
      batchSummaries.push({
        batch: batchNo,
        itemCount: 0,
        summary: compressed
      });
      appendThinking(`Compression round ${state.build.compressionRounds} completed.`);
    }

    if (batchNo < batches.length) {
      await sleep(1200);
    }
  }

  setBuildStage("Synthesizing final narrative", 88, "Building cross-batch summary and messaging");
  const synthesis = await runFinalSynthesis(question, batchSummaries, itemResults);
  return {
    items: itemResults,
    leadershipSummary: synthesis.leadershipSummary || "",
    messaging: synthesis.messaging || {},
    audit: {
      batches: batches.length,
      compressionRounds: state.build.compressionRounds,
      retries: state.build.retries,
      partialFailures: state.build.partialFailures
    }
  };
}

async function runBatchWithRetry(question, batch, snippets, batchNo, totalBatches) {
  let attempt = 0;
  let lastError = null;
  let activeSnippets = snippets;

  while (attempt < 2) {
    attempt += 1;
    try {
      return await runBatchAnalysis(question, batch, activeSnippets, batchNo, totalBatches, attempt);
    } catch (err) {
      lastError = err;
      state.build.retries += 1;
      activeSnippets = activeSnippets.slice(0, Math.max(4, Math.floor(activeSnippets.length / 2)));
      appendThinking(`Batch ${batchNo} attempt ${attempt} failed; retrying with reduced snippets.`);
    }
  }

  if (lastError instanceof Error) throw lastError;
  throw new Error(`Batch ${batchNo} failed`);
}

async function runBatchAnalysis(question, batch, snippets, batchNo, totalBatches, attempt) {
  const compactEpics = batch.map((item) => ({
    number: item.number,
    title: item.title,
    body: String(item.body || "").slice(0, 1800),
    scope: item.scope,
    status: item.projectStatus
  }));

  const response = await runAgentWithRetry({
    sessionId: state.sessionId,
    providerId: state.selectedProvider || undefined,
    model: state.selectedModel || undefined,
    systemPrompt: "You are a product strategy reviewer. Return strict JSON only.",
    userMessage: [
      `Question: ${question}`,
      `Selected release: ${state.selectedRelease}`,
      `Batch ${batchNo}/${totalBatches}, attempt ${attempt}`,
      "Evaluate each epic against strategy snippets and classify aligned/conflict/unclear.",
      "Infer the most fitting investment theme for each epic from strategy snippets.",
      "Return JSON:",
      "{ items:[{ issueNumber:number, investmentTheme:string, classification:'aligned|conflict|unclear', rationale:string, violatedPrinciple:string, citationPath:string, suggestedMessage:string }], batchSummary:string }",
      `Epics: ${JSON.stringify(compactEpics)}`,
      `StrategySnippets: ${JSON.stringify(snippets)}`
    ].join("\n"),
    enabledToolIds: [],
    maxSteps: 4,
    stream: false
  });

  const parsed = parseJson(String(response?.content || ""));
  if (!parsed || typeof parsed !== "object") {
    throw new Error(`Batch ${batchNo} returned invalid JSON`);
  }
  return parsed;
}

async function compressSummaries(summaries) {
  const payload = summaries.map((item) => item.summary).join("\n- ");
  const response = await runAgentWithRetry({
    sessionId: state.sessionId,
    providerId: state.selectedProvider || undefined,
    model: state.selectedModel || undefined,
    systemPrompt: "Summarize analyst notes into a compact factual bullet summary. Return JSON only.",
    userMessage: [
      "Compress these batch summaries while preserving conflict themes and citation paths.",
      "Return JSON: { summary:string }",
      `Summaries:\n- ${payload}`
    ].join("\n"),
    enabledToolIds: [],
    maxSteps: 2,
    stream: false
  });
  const parsed = parseJson(String(response?.content || ""));
  return String(parsed?.summary || payload).slice(0, 6000);
}

async function runFinalSynthesis(question, summaryBlocks, items) {
  const compactItems = items.slice(0, 120).map((item) => ({
    issueNumber: item.issueNumber,
    investmentTheme: item.investmentTheme,
    classification: item.classification,
    violatedPrinciple: item.violatedPrinciple,
    citationPath: item.citationPath,
    suggestedMessage: item.suggestedMessage
  }));

  const response = await runAgentWithRetry({
    sessionId: state.sessionId,
    providerId: state.selectedProvider || undefined,
    model: state.selectedModel || undefined,
    systemPrompt: "Synthesize strategy analysis outputs. Return strict JSON only.",
    userMessage: [
      `Question: ${question}`,
      "Return JSON: { leadershipSummary:string, messaging:{leadership:string, product:string, engineering:string} }",
      `CompressedSummaries: ${JSON.stringify(summaryBlocks.map((item) => item.summary))}`,
      `Items: ${JSON.stringify(compactItems)}`
    ].join("\n"),
    enabledToolIds: [],
    maxSteps: 3,
    stream: false
  });
  return parseJson(String(response?.content || ""));
}

function renderDashboard(epics, docs, analysis, scopeAudit) {
  const byIssue = new Map((analysis?.items || []).map((item) => [String(item.issueNumber), item]));
  const merged = epics.map((issue) => {
    const result = byIssue.get(String(issue.number)) || {};
    return {
      ...issue,
      classification: String(result.classification || "unclear").toLowerCase(),
      investmentTheme: String(result.investmentTheme || "Unmapped"),
      rationale: String(result.rationale || ""),
      violatedPrinciple: String(result.violatedPrinciple || ""),
      citationPath: String(result.citationPath || ""),
      suggestedMessage: String(result.suggestedMessage || "")
    };
  });

  const conflicts = merged.filter((item) => item.classification === "conflict");
  const aligned = merged.filter((item) => item.classification === "aligned");
  const unclear = merged.filter((item) => item.classification !== "aligned" && item.classification !== "conflict");
  const weightedScore = computeWeightedScore(merged);

  el.dashboard.innerHTML = "";
  const kpi = document.createElement("article");
  kpi.className = "card";
  kpi.innerHTML = [
    "<h3>Reality Check</h3>",
    `<div class='kpis'>
      <div class='kpi'><div>Total Epics</div><strong>${merged.length}</strong></div>
      <div class='kpi'><div>Conflicts</div><strong>${conflicts.length}</strong></div>
      <div class='kpi'><div>Aligned</div><strong>${aligned.length}</strong></div>
      <div class='kpi'><div>Unclear</div><strong>${unclear.length}</strong></div>
      <div class='kpi'><div>Weighted Alignment</div><strong>${weightedScore}%</strong></div>
    </div>`
  ].join("");
  el.dashboard.appendChild(kpi);

  const coverage = document.createElement("article");
  coverage.className = "card";
  coverage.innerHTML = [
    "<h3>Scope Coverage</h3>",
    `<div class='kpis'>
      <div class='kpi'><div>Release-labeled</div><strong>${Number(scopeAudit?.releaseLabeledTotal || 0)}</strong></div>
      <div class='kpi'><div>Epic-labeled</div><strong>${Number(scopeAudit?.epicLabeledTotal || 0)}</strong></div>
      <div class='kpi'><div>Analyzed Set</div><strong>${Number(scopeAudit?.strictOverlapTotal || 0)}</strong></div>
      <div class='kpi'><div>Included w/o Epic Label</div><strong>${Number(scopeAudit?.nonEpicInScopeTotal || 0)}</strong></div>
      <div class='kpi'><div>Epic-only</div><strong>${Number(scopeAudit?.epicOnlyTotal || 0)}</strong></div>
    </div>`,
    "<div class='muted'>Score and messaging use release-labeled scope for the selected release.</div>"
  ].join("");
  el.dashboard.appendChild(coverage);

  const audit = document.createElement("article");
  audit.className = "card";
  const auditMeta = analysis?.audit || {};
  audit.innerHTML = [
    "<h3>Audit</h3>",
    `<div class='muted'>Release: ${escapeHtml(state.selectedRelease)} | Product repo: ${escapeHtml(`${state.owner}/${state.repo}`)} | Strategy repo: ${escapeHtml(`${state.strategyOwner}/${state.strategyRepo}@${state.strategyRef}`)}</div>`,
    `<div class='muted'>Scope: target + potential (` + `${Math.round(WEIGHT_TARGET * 100)}/${Math.round(WEIGHT_POTENTIAL * 100)} weighting) | Status source: ${STATUS_PROJECT_ORG}/projects/${STATUS_PROJECT_NUMBER}</div>`,
    `<div class='muted'>Strategy files used: ${docs.length}</div>`,
    `<div class='muted'>Batches: ${Number(auditMeta.batches || 0)} | Compression rounds: ${Number(auditMeta.compressionRounds || 0)} | Retries: ${Number(auditMeta.retries || 0)} | Partial failures: ${Number(auditMeta.partialFailures || 0)}</div>`
  ].join("");
  el.dashboard.appendChild(audit);

  const scopeGaps = document.createElement("article");
  scopeGaps.className = "card";
  scopeGaps.innerHTML = "<h3>Label Hygiene Details</h3><div class='muted'>These rows explain label quality and are not used to define release scope.</div>";
  const nonEpicRows = (scopeAudit?.nonEpicInScope || []).slice(0, 80).map((item) => [
    `#${item.number} ${item.title || ""}`,
    collectReleaseLabels(item).join(", ") || "-",
    item.state || "open",
    item.note || "Included without kind:epic label"
  ]);
  const epicOnlyRows = (scopeAudit?.epicOnly || []).slice(0, 80).map((item) => [
    `#${item.number} ${item.title || ""}`,
    collectReleaseLabels(item).join(", ") || "none",
    item.state || "open",
    item.excludedReason || `No release label for ${state.selectedRelease}`
  ]);

  scopeGaps.appendChild(renderTable([
    "Release-scoped, no epic label",
    "Release Labels",
    "State",
    "Note"
  ], nonEpicRows.length ? nonEpicRows : [["None", "-", "-", "No rows"]]));
  scopeGaps.appendChild(renderTable([
    "Epic-labeled, missing release label",
    "Release Labels",
    "State",
    "Reason"
  ], epicOnlyRows.length ? epicOnlyRows : [["None", "-", "-", "No rows"]]));

  const table = document.createElement("article");
  table.className = "card";
  table.innerHTML = "<h3>Epic Strategy Assessment</h3>";
  const rows = merged.map((item) => [
    `#${item.number} ${item.title || ""}`,
    item.scope,
    item.projectStatus,
    item.investmentTheme || "Unmapped",
    item.classification,
    item.violatedPrinciple || "-",
    item.citationPath || "-",
    item.rationale || ""
  ]);
  table.appendChild(renderTable(["Epic", "Scope", "Status", "Investment Theme", "Assessment", "Principle", "Citation", "Rationale"], rows));
  el.dashboard.appendChild(table);

  const themeMapCard = document.createElement("article");
  themeMapCard.className = "card";
  themeMapCard.innerHTML = "<h3>Epic to Investment Theme Mapping</h3>";
  const themeRows = merged.map((item) => [
    `#${item.number} ${item.title || ""}`,
    item.scope,
    item.investmentTheme || "Unmapped",
    item.classification
  ]);
  themeMapCard.appendChild(renderTable(["Epic", "Scope", "Investment Theme", "Assessment"], themeRows));
  el.dashboard.appendChild(themeMapCard);

  const messaging = document.createElement("article");
  messaging.className = "card";
  const m = analysis?.messaging || {};
  messaging.innerHTML = [
    "<h3>Suggested Messaging</h3>",
    "<div class='muted'>Messaging is generated from release-scoped items for the selected release.</div>",
    `<p><strong>Leadership:</strong> ${escapeHtml(String(m.leadership || analysis?.leadershipSummary || ""))}</p>`,
    `<p><strong>Product:</strong> ${escapeHtml(String(m.product || ""))}</p>`,
    `<p><strong>Engineering:</strong> ${escapeHtml(String(m.engineering || ""))}</p>`
  ].join("");
  el.dashboard.appendChild(messaging);

  el.dashboard.appendChild(scopeGaps);
}

function renderTable(headers, rows) {
  const table = document.createElement("table");
  const thead = document.createElement("thead");
  const headRow = document.createElement("tr");
  headers.forEach((header) => {
    const th = document.createElement("th");
    th.textContent = header;
    headRow.appendChild(th);
  });
  thead.appendChild(headRow);
  table.appendChild(thead);
  const tbody = document.createElement("tbody");
  rows.forEach((cells) => {
    const tr = document.createElement("tr");
    cells.forEach((value) => {
      const td = document.createElement("td");
      td.textContent = String(value || "");
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  return table;
}

function computeWeightedScore(issues) {
  if (!issues.length) return 0;
  let totalWeight = 0;
  let points = 0;
  for (const issue of issues) {
    const weight = issue.scope === "target" ? WEIGHT_TARGET : WEIGHT_POTENTIAL;
    totalWeight += weight;
    if (issue.classification === "aligned") points += weight;
    else if (issue.classification === "unclear") points += weight * 0.5;
  }
  return Math.round((points / Math.max(totalWeight, 0.0001)) * 100);
}

function normalizeLabelToken(value) {
  return String(value || "").trim().toLowerCase().replace(/\s*:\s*/g, ":").replace(/\s+/g, " ");
}

function hasEpicLabel(issue) {
  const labels = Array.isArray(issue?.labels) ? issue.labels : [];
  return labels.some((label) => normalizeLabelToken(label) === "kind:epic");
}

function hasReleaseLabelFor(issue, release) {
  const key = extractReleaseKey(release);
  if (!key) return false;
  const labels = Array.isArray(issue?.labels) ? issue.labels : [];
  for (const label of labels) {
    const raw = String(label || "").trim();
    const scoped = parseScopedReleaseLabel(raw);
    if (scoped && scoped.release === key) return true;
    const versionOnly = extractReleaseKey(raw);
    if (versionOnly && versionOnly === key) return true;
  }
  return false;
}

function issueHasAnyReleaseLabel(issue) {
  const labels = Array.isArray(issue?.labels) ? issue.labels : [];
  for (const label of labels) {
    const raw = String(label || "").trim();
    if (parseScopedReleaseLabel(raw)) return true;
    if (extractReleaseKey(raw)) return true;
  }
  return false;
}

function collectReleaseLabels(issue) {
  const labels = Array.isArray(issue?.labels) ? issue.labels : [];
  return labels.filter((label) => {
    const raw = String(label || "").trim();
    return !!parseScopedReleaseLabel(raw) || !!extractReleaseKey(raw);
  });
}

async function getReleaseLabelCatalog() {
  const labels = await invokeInsight("github.listLabels", {
    owner: state.owner,
    repo: state.repo,
    per_page: 100,
    max_pages: 5
  });
  const targetByRelease = new Map();
  const potentialByRelease = new Map();
  const versionOnlyByRelease = new Map();

  for (const label of labels.labels || []) {
    const name = String(label.name || "").trim();
    if (!name) continue;
    const scoped = parseScopedReleaseLabel(name);
    if (scoped) {
      if (scoped.scope === "target") {
        pushToReleaseMap(targetByRelease, scoped.release, name);
      } else {
        pushToReleaseMap(potentialByRelease, scoped.release, name);
      }
      continue;
    }
    const versionOnly = extractReleaseKey(name);
    if (versionOnly) {
      pushToReleaseMap(versionOnlyByRelease, versionOnly, name);
    }
  }
  const releases = Array.from(new Set([
    ...targetByRelease.keys(),
    ...potentialByRelease.keys(),
    ...versionOnlyByRelease.keys()
  ])).sort(compareSemver);
  return {
    releases,
    targetByRelease,
    potentialByRelease,
    versionOnlyByRelease
  };
}

async function resolveScopeLabelsForRelease(release, kind) {
  const catalog = await getReleaseLabelCatalog();
  const targetList = catalog.targetByRelease?.get(release) || [];
  const potentialList = catalog.potentialByRelease?.get(release) || [];
  const versionOnlyList = catalog.versionOnlyByRelease?.get(release) || [];
  const exact = (kind === "target" ? targetList : potentialList).slice();
  if (!exact.length && versionOnlyList.length) {
    exact.push(...versionOnlyList);
  }
  if (exact.length) {
    return { labels: exact, display: exact.join(", ") };
  }
  return {
    labels: [`release ${kind} ${release}`],
    display: `release ${kind} ${release}`
  };
}

function parseScopedReleaseLabel(labelName) {
  const match = String(labelName).match(/^(target|potential|committed)\s*[:\s]\s*(.+)$/i);
  if (!match) return null;
  const rawScope = String(match[1] || "").toLowerCase();
  const release = extractReleaseKey(match[2]);
  if (!release) return null;
  return {
    scope: rawScope === "potential" ? "potential" : "target",
    release
  };
}

function extractReleaseKey(value) {
  const match = String(value || "").match(/(\d+)\.(\d+)/);
  if (!match) return null;
  return `${Number(match[1])}.${Number(match[2])}`;
}

function pushToReleaseMap(map, release, label) {
  const list = map.get(release) || [];
  if (!list.includes(label)) list.push(label);
  map.set(release, list);
}

async function getIssuesForLabels(labels) {
  const scopeLabels = Array.from(new Set((labels || []).map((v) => String(v || "").trim()).filter(Boolean)));
  if (!scopeLabels.length) return [];
  const responses = await Promise.all(scopeLabels.map((label) => invokeInsight("github.listIssues", {
    owner: state.owner,
    repo: state.repo,
    labels: [label],
    state: "all",
    per_page: 100,
    max_pages: 8
  })));

  const deduped = new Map();
  for (const response of responses) {
    for (const issue of response.issues || []) {
      const key = String(issue.id || issue.number || "");
      if (!key) continue;
      deduped.set(key, issue);
    }
  }
  return Array.from(deduped.values());
}

async function getAllIssuesForAudit() {
  const response = await invokeInsight("github.listIssues", {
    owner: state.owner,
    repo: state.repo,
    state: "all",
    per_page: 100,
    max_pages: 10
  });
  return Array.isArray(response?.issues) ? response.issues : [];
}

async function invokeInsight(toolId, input) {
  const result = await window.AgenticOS.tools.invoke(toolId, input, state.sessionId);
  return result.output || {};
}

function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    const match = String(text || "").match(/\{[\s\S]*\}/);
    if (!match) return {};
    try {
      return JSON.parse(match[0]);
    } catch {
      return {};
    }
  }
}

function compareSemver(a, b) {
  const pa = String(a || "").split(".").map((v) => Number(v));
  const pb = String(b || "").split(".").map((v) => Number(v));
  for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
    const da = Number.isFinite(pa[i]) ? pa[i] : 0;
    const db = Number.isFinite(pb[i]) ? pb[i] : 0;
    if (da !== db) return da - db;
  }
  return 0;
}

async function runAgentWithRetry(payload, maxAttempts = 3) {
  let attempt = 0;
  let lastError = null;
  while (attempt < maxAttempts) {
    attempt += 1;
    try {
      return await window.AgenticOS.rpc.invoke("sessions.runAgent", payload);
    } catch (err) {
      lastError = err;
      const message = String(err?.message || err || "");
      const waitMs = parseRateLimitWaitMs(message);
      if (!waitMs || attempt >= maxAttempts) {
        throw err;
      }
      appendThinking(`Rate limit reached; waiting ${Math.ceil(waitMs / 1000)}s before retry ${attempt + 1}/${maxAttempts}.`);
      setBuildStage("Rate limit wait", 70, `Waiting ${Math.ceil(waitMs / 1000)}s for model quota reset`);
      await sleep(waitMs);
    }
  }
  throw lastError || new Error("runAgent retry exhausted");
}

function parseRateLimitWaitMs(message) {
  const text = String(message || "");
  if (!/\b429\b|RateLimitReached|rate limit/i.test(text)) return 0;
  const secMatch = text.match(/wait\s+(\d+)\s+seconds?/i);
  if (secMatch) {
    const sec = Number(secMatch[1]);
    if (Number.isFinite(sec) && sec > 0) return sec * 1000 + 1000;
  }
  return RATE_LIMIT_WAIT_MS;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function setStatus(text, isError = false) {
  el.status.textContent = String(text || "");
  el.status.style.color = isError ? "var(--danger)" : "var(--muted)";
}

function renderWelcome() {
  el.dashboard.innerHTML = "";
  const card = document.createElement("article");
  card.className = "card";
  card.innerHTML = "<h3>Ready</h3><div class='muted'>Paste text to review. Baseline files provide direction only.</div>";
  el.dashboard.appendChild(card);
}

function startBuildFlow() {
  state.build.active = true;
  state.build.steps = [];
  state.build.batches = 0;
  state.build.compressionRounds = 0;
  state.build.retries = 0;
  state.build.partialFailures = 0;
  el.buildPanel.classList.remove("hidden");
  el.buildProgressBar.style.width = "0%";
  el.buildStage.textContent = "Starting";
  el.buildDetail.textContent = "Preparing analysis";
  renderThinkingPanel();
}

function finishBuildFlow() {
  state.build.active = false;
}

function setBuildStage(stage, progress, detail) {
  el.buildStage.textContent = String(stage || "");
  el.buildDetail.textContent = String(detail || "");
  const pct = Math.max(0, Math.min(100, Number(progress) || 0));
  el.buildProgressBar.style.width = `${pct}%`;
  appendThinking(`${stage}: ${detail}`);
}

function appendThinking(line) {
  const text = String(line || "").trim();
  if (!text) return;
  state.build.steps.push({ at: Date.now(), text });
  if (state.build.steps.length > 120) {
    state.build.steps = state.build.steps.slice(-120);
  }
  renderThinkingPanel();
}

function renderThinkingPanel() {
  el.toggleThinking.setAttribute("aria-expanded", state.build.showThinking ? "true" : "false");
  el.toggleThinking.textContent = state.build.showThinking ? "Hide Thinking" : "Show Thinking";
  el.thinkingLog.classList.toggle("hidden", !state.build.showThinking);
  if (!state.build.showThinking) return;
  el.thinkingLog.innerHTML = "";
  state.build.steps.forEach((entry) => {
    const row = document.createElement("div");
    row.className = "thinking-item";
    row.textContent = `${new Date(entry.at).toLocaleTimeString()} - ${entry.text}`;
    el.thinkingLog.appendChild(row);
  });
  el.thinkingLog.scrollTop = el.thinkingLog.scrollHeight;
}

function chunkArray(list, size) {
  const out = [];
  for (let i = 0; i < list.length; i += size) {
    out.push(list.slice(i, i + size));
  }
  return out;
}

function buildStrategySnippetIndex(docs) {
  const snippets = [];
  for (const doc of docs || []) {
    const path = String(doc.path || "");
    const text = String(doc.content || "").replace(/\r/g, "");
    const parts = text.split(/\n\s*\n/g).map((p) => p.trim()).filter(Boolean);
    let chunkIndex = 0;
    let buffer = "";
    for (const part of parts) {
      const candidate = buffer ? `${buffer}\n\n${part}` : part;
      if (candidate.length > MAX_SNIPPET_CHARS && buffer) {
        snippets.push({ path, chunk: chunkIndex, content: buffer.slice(0, MAX_SNIPPET_CHARS) });
        chunkIndex += 1;
        buffer = part;
      } else {
        buffer = candidate;
      }
    }
    if (buffer) {
      snippets.push({ path, chunk: chunkIndex, content: buffer.slice(0, MAX_SNIPPET_CHARS) });
    }
  }
  return snippets;
}

function selectStrategySnippetsForBatch(batch, snippetIndex, maxSnippets) {
  const keywords = new Set();
  for (const epic of batch || []) {
    String(epic.title || "").toLowerCase().split(/[^a-z0-9]+/g).forEach((token) => {
      if (token.length >= 5) keywords.add(token);
    });
  }

  const scored = (snippetIndex || []).map((snippet) => {
    const content = String(snippet.content || "").toLowerCase();
    let score = 0;
    keywords.forEach((token) => {
      if (content.includes(token)) score += 1;
    });
    if (score === 0) score = 0.1;
    return { ...snippet, score };
  }).sort((a, b) => b.score - a.score);

  return scored.slice(0, maxSnippets).map((item) => ({
    path: item.path,
    snippetRef: `${item.path}#${item.chunk}`,
    content: String(item.content || "")
  }));
}

function escapeHtml(text) {
  return String(text || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
