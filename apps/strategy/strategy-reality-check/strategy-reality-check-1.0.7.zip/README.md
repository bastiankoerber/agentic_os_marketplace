# Strategy Reality Check

Compares release epics against strategic documents and highlights alignment conflicts.

## What it does
- Uses manual release selection from Product Hub release labels.
- Pulls both target and potential `kind:epic` items (weighted 70/30 toward target).
- Reads selected strategy documents from a configurable GitHub repository.
- Produces a deterministic scope audit plus LLM-based conflict assessment and suggested messaging.

## Key assumptions
- Product status source of truth is GitHub ProjectV2 `camunda/projects/9` `Status`.
- Strategy analysis is limited to explicitly selected files in the Strategy Files modal.
