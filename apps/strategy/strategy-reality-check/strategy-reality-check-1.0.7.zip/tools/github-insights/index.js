const BASE_URL = "https://api.github.com";

exports.invoke = async (toolId, input, context) => {
  switch (toolId) {
    case "github.listRepoFiles":
      return listRepoFiles(input, context);
    case "github.getIssueProjectFields":
      return getIssueProjectFields(input, context);
    case "github.listIssues":
      return listIssues(input, context);
    case "github.listLabels":
      return listLabels(input, context);
    case "github.getFile":
      return getFile(input, context);
    default:
      throw new Error(`Unknown tool: ${toolId}`);
  }
};

async function listRepoFiles(input, context) {
  const owner = resolveOwner(input, context);
  const repo = resolveRepo(input, context);
  if (!owner || !repo) throw new Error("github.listRepoFiles requires 'owner' and 'repo'");
  const ref = String(input?.ref || "").trim();
  const root = String(input?.path || "").trim();
  const include = String(input?.include_glob || "").trim();
  const token = resolveToken(input, context);
  const timeoutMs = resolveTimeout(input, context);

  const endpoint = new URL(`${BASE_URL}/repos/${enc(owner)}/${enc(repo)}/git/trees/${encodeURIComponent(ref || "HEAD")}?recursive=1`);
  const data = await requestJson(endpoint.toString(), { token, timeoutMs });
  const tree = Array.isArray(data?.tree) ? data.tree : [];
  const files = tree
    .filter((item) => item?.type === "blob")
    .map((item) => String(item.path || ""))
    .filter((path) => {
      if (!path) return false;
      if (root && !(path === root || path.startsWith(`${root}/`))) return false;
      if (include === "**/*.md") return /\.md$/i.test(path);
      return true;
    })
    .sort((a, b) => a.localeCompare(b));

  return {
    files,
    mode: token ? "authenticated" : "unauthenticated"
  };
}

async function getIssueProjectFields(input, context) {
  const owner = resolveOwner(input, context);
  const repo = resolveRepo(input, context);
  const issueNumber = Number(input?.issue_number);
  if (!owner || !repo || !Number.isInteger(issueNumber) || issueNumber <= 0) {
    throw new Error("github.getIssueProjectFields requires 'owner', 'repo', and positive integer 'issue_number'");
  }
  const token = resolveToken(input, context);
  if (!token) {
    throw new Error("github.getIssueProjectFields requires a GitHub token");
  }
  const timeoutMs = resolveTimeout(input, context);
  const org = String(input?.org || "").trim().toLowerCase();
  const projectNumber = Number(input?.project_number);
  const statusFieldName = String(input?.status_field || "Status").trim().toLowerCase();

  const query = `
    query IssueProjectFields($owner: String!, $repo: String!, $issueNumber: Int!) {
      repository(owner: $owner, name: $repo) {
        issue(number: $issueNumber) {
          projectItems(first: 50) {
            nodes {
              updatedAt
              project {
                number
                title
                url
                owner {
                  __typename
                  ... on Organization { login }
                  ... on User { login }
                }
              }
              fieldValues(first: 50) {
                nodes {
                  ... on ProjectV2ItemFieldSingleSelectValue {
                    name
                    field {
                      ... on ProjectV2Field { name }
                      ... on ProjectV2SingleSelectField { name }
                    }
                  }
                  ... on ProjectV2ItemFieldTextValue {
                    text
                    field {
                      ... on ProjectV2Field { name }
                      ... on ProjectV2SingleSelectField { name }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  `;

  const data = await requestGraphql(query, { owner, repo, issueNumber }, { token, timeoutMs });
  const items = Array.isArray(data?.repository?.issue?.projectItems?.nodes) ? data.repository.issue.projectItems.nodes : [];

  const mapped = items.map((item) => {
    const fields = {};
    let status = "";
    const fieldValues = Array.isArray(item?.fieldValues?.nodes) ? item.fieldValues.nodes : [];
    fieldValues.forEach((entry) => {
      const fieldName = String(entry?.field?.name || "").trim();
      if (!fieldName) return;
      const value = String(entry?.name || entry?.text || "").trim();
      fields[fieldName] = value;
      if (!status && fieldName.toLowerCase() === statusFieldName) status = value;
    });
    return {
      project_number: Number(item?.project?.number || 0),
      project_title: String(item?.project?.title || ""),
      project_url: String(item?.project?.url || ""),
      project_owner: String(item?.project?.owner?.login || "").toLowerCase(),
      item_updated_at: String(item?.updatedAt || ""),
      status,
      fields
    };
  }).filter((item) => {
    if (org && item.project_owner !== org) return false;
    if (Number.isFinite(projectNumber) && projectNumber > 0 && item.project_number !== projectNumber) return false;
    return true;
  }).sort((a, b) => String(b.item_updated_at || "").localeCompare(String(a.item_updated_at || "")));

  return {
    status: mapped[0]?.status || "",
    selected: mapped[0] || null,
    items: mapped,
    mode: "authenticated"
  };
}

async function listIssues(input, context) {
  const owner = resolveOwner(input, context);
  const repo = resolveRepo(input, context);
  if (!owner || !repo) throw new Error("github.listIssues requires 'owner' and 'repo'");
  const state = String(input?.state || "open");
  const perPage = clampNumber(input?.per_page, 1, 100, 30);
  const maxPages = clampNumber(input?.max_pages, 1, 10, 2);
  const labels = normalizeLabels(input?.labels);
  const token = resolveToken(input, context);
  const timeoutMs = resolveTimeout(input, context);

  const query = new URLSearchParams();
  query.set("state", state);
  if (labels.length) query.set("labels", labels.join(","));
  const data = await fetchPaginated(`/repos/${enc(owner)}/${enc(repo)}/issues?${query.toString()}`, {
    perPage,
    maxPages,
    token,
    timeoutMs
  });

  const issues = data.filter((issue) => !issue.pull_request).map((issue) => ({
    id: issue.id,
    number: issue.number,
    title: issue.title,
    body: issue.body || "",
    state: issue.state,
    html_url: issue.html_url,
    user: issue.user?.login || "",
    assignee: issue.assignee?.login || null,
    created_at: issue.created_at,
    updated_at: issue.updated_at,
    closed_at: issue.closed_at,
    labels: Array.isArray(issue.labels) ? issue.labels.map((label) => (typeof label === "string" ? label : label.name)) : []
  }));

  return { issues, items: issues, mode: token ? "authenticated" : "unauthenticated" };
}

async function listLabels(input, context) {
  const owner = resolveOwner(input, context);
  const repo = resolveRepo(input, context);
  if (!owner || !repo) throw new Error("github.listLabels requires 'owner' and 'repo'");
  const perPage = clampNumber(input?.per_page, 1, 100, 100);
  const maxPages = clampNumber(input?.max_pages, 1, 10, 5);
  const token = resolveToken(input, context);
  const timeoutMs = resolveTimeout(input, context);
  const labels = await fetchPaginated(`/repos/${enc(owner)}/${enc(repo)}/labels`, {
    perPage,
    maxPages,
    token,
    timeoutMs
  });
  return {
    labels: labels.map((label) => ({ id: label.id, name: label.name, color: label.color, description: label.description || "" })),
    mode: token ? "authenticated" : "unauthenticated"
  };
}

async function getFile(input, context) {
  const owner = resolveOwner(input, context);
  const repo = resolveRepo(input, context);
  const filePath = String(input?.path || "").trim();
  if (!owner || !repo || !filePath) throw new Error("github.getFile requires 'owner', 'repo', and 'path'");
  const ref = String(input?.ref || "").trim();
  const token = resolveToken(input, context);
  const timeoutMs = resolveTimeout(input, context);
  const url = new URL(`${BASE_URL}/repos/${enc(owner)}/${enc(repo)}/contents/${encodeURIComponent(filePath).replace(/%2F/g, "/")}`);
  if (ref) url.searchParams.set("ref", ref);
  const data = await requestJson(url.toString(), { token, timeoutMs });
  const encoded = typeof data.content === "string" ? data.content.replace(/\n/g, "") : "";
  const decoded = encoded ? Buffer.from(encoded, "base64").toString("utf-8") : "";
  return {
    path: data.path || filePath,
    content: decoded,
    mode: token ? "authenticated" : "unauthenticated"
  };
}

async function fetchPaginated(endpoint, options) {
  const results = [];
  for (let page = 1; page <= options.maxPages; page += 1) {
    const url = new URL(endpoint.startsWith("http") ? endpoint : `${BASE_URL}${endpoint}`);
    if (!url.searchParams.has("per_page")) url.searchParams.set("per_page", String(options.perPage));
    url.searchParams.set("page", String(page));
    const data = await requestJson(url.toString(), { token: options.token, timeoutMs: options.timeoutMs });
    if (!Array.isArray(data) || !data.length) break;
    results.push(...data);
    if (data.length < options.perPage) break;
  }
  return results;
}

async function requestJson(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs);
  try {
    const headers = {
      Accept: "application/vnd.github+json",
      "User-Agent": "agenticos-github"
    };
    if (options.token) {
      headers.Authorization = `Bearer ${options.token}`;
    }
    const response = await fetch(url, {
      method: options.method || "GET",
      headers,
      signal: controller.signal,
      body: options.body ? JSON.stringify(options.body) : undefined
    });
    const text = await response.text();
    const data = safeJson(text);
    if (!response.ok) {
      const detail = data?.message || text || `status ${response.status}`;
      throw new Error(`GitHub API error: ${detail}`);
    }
    return data;
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new Error(`GitHub request timed out after ${options.timeoutMs}ms`);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

async function requestGraphql(query, variables, options) {
  const data = await requestJson(`${BASE_URL}/graphql`, {
    token: options.token,
    timeoutMs: options.timeoutMs,
    method: "POST",
    body: { query, variables }
  });
  if (Array.isArray(data?.errors) && data.errors.length) {
    throw new Error(`GitHub GraphQL error: ${data.errors.map((e) => String(e?.message || "")).join("; ")}`);
  }
  return data?.data || {};
}

function resolveToken(input, context) {
  const inToken = String(input?.token || "").trim();
  if (inToken) return inToken;
  const settings = (context && context.settings) || {};
  if (typeof settings.token === "string" && settings.token.trim()) return settings.token.trim();
  return "";
}

function resolveOwner(input, context) {
  const owner = String(input?.owner || "").trim();
  if (owner) return owner;
  const settings = (context && context.settings) || {};
  if (typeof settings.owner === "string" && settings.owner.trim()) return settings.owner.trim();
  if (typeof settings.default_owner === "string" && settings.default_owner.trim()) return settings.default_owner.trim();
  return "";
}

function resolveRepo(input, context) {
  const repo = String(input?.repo || "").trim();
  if (repo) return repo;
  const settings = (context && context.settings) || {};
  if (typeof settings.repo === "string" && settings.repo.trim()) return settings.repo.trim();
  if (typeof settings.default_repo === "string" && settings.default_repo.trim()) return settings.default_repo.trim();
  return "";
}

function resolveTimeout(input, context) {
  const settings = (context && context.settings) || {};
  const fromInput = Number(input?.timeout_ms);
  const fromSettings = Number(settings.timeout_ms);
  if (!Number.isNaN(fromInput)) return clampNumber(fromInput, 2000, 60000, 15000);
  if (!Number.isNaN(fromSettings)) return clampNumber(fromSettings, 2000, 60000, 15000);
  return 15000;
}

function normalizeLabels(value) {
  if (Array.isArray(value)) return value.map((v) => String(v || "").trim()).filter(Boolean);
  if (typeof value === "string") return value.split(",").map((v) => v.trim()).filter(Boolean);
  return [];
}

function safeJson(text) {
  try {
    return JSON.parse(text || "null");
  } catch {
    return null;
  }
}

function clampNumber(value, min, max, fallback) {
  const num = Number(value);
  if (Number.isNaN(num)) return fallback;
  return Math.max(min, Math.min(max, num));
}

function enc(value) {
  return encodeURIComponent(String(value));
}
